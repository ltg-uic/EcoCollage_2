//
//  OpenCVMethods.m
//  UITouchImage
//
//  Created by LTG_Ugrad on 4/10/15.
//  Copyright (c) 2015 LTG_Ugrad. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UIImage+OpenCV.h"
#import "OpenCVMethods.h"
using namespace cv;
using namespace std;

@implementation OpenCVMethods

int a[8];

//Returns image with a Gaussian Blur Filter applied to it
+ (UIImage *) ApplyMedianFilter: (UIImage *) img
{
    //apply a gaussian blur filter to the image
    Mat m = [img CVMat3];
    Mat m_blur;
    m.copyTo(m_blur);
    
    medianBlur ( m, m_blur, 15 );
    
    UIImage* retImg = [UIImage imageWithCVMat:m_blur];
    
    return retImg;
}

// returns a grayscaled image
+ (UIImage *) DrawnGrayScaleImage: (UIImage *) image
{
    Mat m = [image CVMat3];
    Mat m_grey;
    
    //convert to grayscale
    cv::cvtColor(m, m_grey, CV_BGR2GRAY);
    
    //return as a UIIMage
    UIImage* retImg = [UIImage imageWithCVMat:m_grey];
    
    return retImg;
}

IplImage* thresh(IplImage* img,int colorCase){
    
    //Convert the image into an HSV image
    IplImage * imgHSV = cvCreateImage(cvGetSize(img), 8, 3);
    cvCvtColor(img, imgHSV, CV_BGR2HSV);
    
    
    //New image that will hold the thresholded image
    IplImage * imgThreshed = cvCreateImage(cvGetSize(img), 8, 1);
    
    
    //*******************************Projector On***************************************//
    //**	white
    //		cvInRangeS(imgHSV, cvScalar(0, 0, 0), cvScalar(20, 55, 255), imgThreshed);
    //**	white on black
    //		cvInRangeS(imgHSV, cvScalar(0, 0, 200), cvScalar(360, 40, 255), imgThreshed);
    //**	red
    //		cvInRangeS(imgHSV, cvScalar(0, 100, 50), cvScalar(15, 200, 150), imgThreshed);
    //**	orange
    //		cvInRangeS(imgHSV, cvScalar(10, 100, 0), cvScalar(30, 250, 175), imgThreshed);
    //**	green
    //		cvInRangeS(imgHSV, cvScalar(30, 50, 50), cvScalar(90, 200, 130), imgThreshed);
    //**	wood
    //		cvInRangeS(imgHSV, cvScalar(10, 50, 120), cvScalar(30, 100, 165), imgThreshed);
    //**	blue
    //		cvInRangeS(imgHSV, cvScalar(90, 0, 40), cvScalar(150, 90, 130), imgThreshed);
    //**	black
    //		cvInRangeS(imgHSV, cvScalar(0, 0, 0), cvScalar(180, 190, 90), imgThreshed);
    
    
    //*******************************Projector Off***************************************//
    //**	black on white
    //		cvInRangeS(imgHSV, cvScalar(0, 0, 0), cvScalar(20, 55, 255), imgThreshed);
    //**	red
    //		cvInRangeS(imgHSV, cvScalar(0, 100, 50), cvScalar(15, 255, 130), imgThreshed);
    //**	orange
    //		cvInRangeS(imgHSV, cvScalar(5, 100, 60), cvScalar(30, 225, 130), imgThreshed);
    //**	green
    //		cvInRangeS(imgHSV, cvScalar(40, 75, 50), cvScalar(90, 255, 150), imgThreshed);
    //**	wood
    //		cvInRangeS(imgHSV, cvScalar(15, 60, 90), cvScalar(60, 200, 200), imgThreshed);
    //**	blue
    //		cvInRangeS(imgHSV, cvScalar(90, 90, 20), cvScalar(150, 200, 90), imgThreshed);
    //**	black
    //		cvInRangeS(imgHSV, cvScalar(0, 0, 0), cvScalar(100, 200, 30), imgThreshed);
    //**	silicon blue
    //		cvInRangeS(imgHSV, cvScalar(90, 100, 50), cvScalar(150, 220, 120), imgThreshed);
    
    //*************NEW******************Projector Off*********************COLORS******************//
    //**	red
    //		cvInRangeS(imgHSV, cvScalar(0, 60, 60), cvScalar(15, 200, 255), imgThreshed);
    //**	blue
    //      cvInRangeS(imgHSV, cvScalar(90, 40, 50), cvScalar(150, 255, 200), imgThreshed);
    //**	orange
    //		cvInRangeS(imgHSV, cvScalar(0, 60, 50), cvScalar(30, 190, 150), imgThreshed);
    //**	green
    //		cvInRangeS(imgHSV, cvScalar(40, 75, 50), cvScalar(90, 255, 150), imgThreshed);
    //**	Yellow
    //		cvInRangeS(imgHSV, cvScalar(5, 40, 60), cvScalar(40, 225, 225), imgThreshed);
    //**	gray
    //		cvInRangeS(imgHSV, cvScalar(90, 50, 0), cvScalar(100, 255, 255), imgThreshed);
    
    
    switch(colorCase){
        case 0: // green
            //cvInRangeS(imgHSV, cvScalar(10, 50, 50), cvScalar(80, 200, 255), imgThreshed);
            cvInRangeS(imgHSV, cvScalar(10, 50, 50), cvScalar(80, 200, 255), imgThreshed);
            break;
        case 1: // red
            //cvInRangeS(imgHSV, cvScalar(80, 100, 100), cvScalar(175, 255, 255), imgThreshed);
            cvInRangeS(imgHSV, cvScalar(80, 140, 127), cvScalar(175, 255, 255), imgThreshed);
            break;
        case 2: // brown/wood
            //cvInRangeS(imgHSV, cvScalar(100, 40, 50), cvScalar(240, 100, 225), imgThreshed);
            cvInRangeS(imgHSV, cvScalar(100, 40, 50), cvScalar(240, 100, 225), imgThreshed);
            break;
        case 3: // blue
            //cvInRangeS(imgHSV, cvScalar(0, 30, 50), cvScalar(15, 200, 150), imgThreshed);
            cvInRangeS(imgHSV, cvScalar(0, 30, 50), cvScalar(15, 210, 210), imgThreshed);
            break;
        case 4: // black
            cvInRangeS(imgHSV, cvScalar(0, 0, 70), cvScalar(255, 255, 255), imgThreshed);
            break;
        case 6: // dark green (corner markers)
            cvInRangeS(imgHSV, cvScalar(15, 35, 35), cvScalar(90, 200, 130), imgThreshed);
            break;
        default:
            break;
    }
    
    
    //Release the temp HSV image and return this thresholded image
    cvReleaseImage(&imgHSV);
    return imgThreshed;
}

int getCorners(IplImage * img, IplImage * original, CvPoint pts[], int frameNumber, int colorCase, bool writeToFile)
{
    CvSeq * contours;
    CvSeq * result;
    CvMemStorage * storage = cvCreateMemStorage(0);
    IplImage * temp = cvCloneImage(img);
    
    // keeping track of current index in CvPoint* pts[]
    int ptsIndex = 0;
    cvFindContours(temp, storage, &contours, sizeof(CvContour), CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE, cvPoint(0,0));
    
    while(contours)
    {
        
        result = cvApproxPoly(contours, sizeof(CvContour), storage, CV_POLY_APPROX_DP, cvContourPerimeter(contours) * 0.02, 0);
        
        if(result->total>=3 && fabs(cvContourArea(result, CV_WHOLE_SEQ)) > 40)
        {
            
            CvPoint * pt[result->total];
            for(int i=0;i < result->total; i++) {
                pt[i] = (CvPoint * )cvGetSeqElem(result, i);
                CvPoint tempPoint;
                tempPoint.x = pt[i]->x;
                tempPoint.y = pt[i]->y;
                pts[ptsIndex] = tempPoint;
                ptsIndex++;
            }
        }
        contours = contours -> h_next;
    }
    
    cvReleaseImage(&temp);
    cvReleaseMemStorage(&storage);
    return ptsIndex;
}

+ (int) detectContours:(UIImage *)src corners:(int[]) cornersGlobal
{
    
    // needed to make new image because next comment was causing conversion error
    UIImage *new_src = nil;
    CGSize targetSize = src.size;
    UIGraphicsBeginImageContext(targetSize);
    
    CGRect thumbnailRect = CGRectMake(0, 0, 0, 0);
    thumbnailRect.origin = CGPointMake(0.0,0.0);
    thumbnailRect.size.width  = targetSize.width;
    thumbnailRect.size.height = targetSize.height;
    
    [src drawInRect:thumbnailRect];
    
    
    new_src = UIGraphicsGetImageFromCurrentImageContext();
    
    
    UIGraphicsEndImageContext();
    
    // needed to make new image (new_src) because this was causing a conversion error
    Mat mat_src = [new_src CVMat3];
    
    IplImage copy_src = mat_src;
    IplImage* ipl_src = &copy_src;
    
    
    
    // convert to black and white image for cvFindContours
    // used in stitching.cpp function getCorners
    
    cv::Mat bwImage;
    cv::cvtColor(mat_src, bwImage, CV_RGB2GRAY);
    
    
    copy_src = bwImage;
    ipl_src = &copy_src;
    
    IplImage* ipl_dst = ipl_src;
    
    //ERROR
    CvPoint pts[500];
    
    
    
    int ptsNumber = getCorners(ipl_src, ipl_dst, pts, 5, 4, 0);
    
    int i = 0;
    //ERRORS OCCURRING
    //pts WITHOUT X OR Y VALUES FROM getCorners
    //EVEN THOUGH EACH PT SHOULD HAVE BEEN POPULATED WITHIN THE FUNCTION
    while(i < ptsNumber) {
        int x = pts[i].x;
        int y = pts[i].y;
        printf("x: %d y: %d\n", x, y);
        i++;
    }
    
    
    int src_width = src.size.width - 1;
    int src_height = src.size.height - 1;
    
    
    // 0 1
    // 3 2
    CvPoint corners[4];
    corners[0] = cvPoint(0, 0);
    corners[1] = cvPoint(src_width, 0);
    corners[2] = cvPoint(src_width, src_height);
    corners[3] = cvPoint(0, src_height);
    
    // 0 1
    // 3 2
    CvPoint boardCorners[4];
    boardCorners[0] = cvPoint(src_width, src_height);
    boardCorners[1] = cvPoint(0, src_height);
    boardCorners[2] = cvPoint(0, 0);
    boardCorners[3] = cvPoint(src_width, 0);
    
    
    double curr_dist0 = 10000;
    double curr_dist1 = 10000;
    double curr_dist2 = 10000;
    double curr_dist3 = 10000;
    
    
    // description of the following code (until the end of this function):
    // find amongst all the points within the contours the points closest to each corner of the image
    // these points are the corners of the board and will be used in the perspective warp
    // the following is how corners are set up. 0 is top left and then it moves clockwise
    // 0-------1
    // |       |
    // |       |
    // |       |
    // |       |
    // 3-------2
    //
    for(i = 0; i < ptsNumber; i++) {
        //if (pts[i].x > 20 && pts[i].y > 20 && pts[i].x < (src_width - 20) && pts[i].y < (src_height - 20)) {
        
        double dx0 = (double)(abs(corners[0].x - pts[i].x));
        double dy0 = (double)(abs(corners[0].y - pts[i].y));
        double dx1 = (double)(abs(corners[1].x - pts[i].x));
        double dy1 = (double)(abs(corners[1].y - pts[i].y));
        double dx2 = (double)(abs(corners[2].x - pts[i].x));
        double dy2 = (double)(abs(corners[2].y - pts[i].y));
        double dx3 = (double)(abs(corners[3].x - pts[i].x));
        double dy3 = (double)(abs(corners[3].y - pts[i].y));
        
        double dist0 = sqrt((dx0 * dx0) + (dy0 * dy0));
        double dist1 = sqrt((dx1 * dx1) + (dy1 * dy1));
        double dist2 = sqrt((dx2 * dx2) + (dy2 * dy2));
        double dist3 = sqrt((dx3 * dx3) + (dy3 * dy3));
        
        
        if(dist0 < curr_dist0) {
            boardCorners[0] = pts[i];
            curr_dist0 = dist0;
        }
        if(dist1 < curr_dist1) {
            boardCorners[1] = pts[i];
            curr_dist1 = dist1;
        }
        if(dist2 < curr_dist2) {
            boardCorners[2] = pts[i];
            curr_dist2 = dist2;
        }
        if(dist3 < curr_dist3) {
            boardCorners[3] = pts[i];
            curr_dist3 = dist3;
        }
        //}
    }
    
    
    // following code tries to force a crop of only the map
    // (get rid of borders such as corner markers)
    // length between top left and top right corners
    int xBetween0_1 = abs(boardCorners[1].x - boardCorners[0].x);
    // length between bottom left and bottom right corners
    int xBetween2_3 = abs(boardCorners[2].x - boardCorners[3].x);
    // length between top left and bottom left corners
    int yBetween0_3 = abs(boardCorners[3].y - boardCorners[0].y);
    // length between bottom right and top right corners
    int yBetween1_2 = abs(boardCorners[2].y - boardCorners[1].y);
    
    
    // original divisors: 24, 24, 40, 40
    int xCrop0_1 = xBetween0_1 / 14;
    int xCrop2_3 = xBetween2_3 / 9;
    int yCrop0_3 = yBetween0_3 / 8;
    int yCrop1_2 = yBetween1_2 / 8;
    
    // crop out the corner markers from the image of the map
    boardCorners[0].x += xCrop0_1;
    boardCorners[0].y += yCrop0_3 / 3;
    boardCorners[1].x -= xCrop0_1;
    boardCorners[1].y += yCrop1_2 / 3;
    boardCorners[2].x -= xCrop2_3;
    boardCorners[2].y -= yCrop1_2;
    boardCorners[3].x += xCrop2_3;
    boardCorners[3].y -= yCrop0_3;
    
    
    /*
     // extend crop 10 pixels above top left corner
     if(boardCorners[0].y > 10 ) {
     boardCorners[0].y -= 10;
     }
     */
    
    a[0] = boardCorners[0].x;
    a[1] = boardCorners[0].y;
    a[2] = boardCorners[1].x;
    a[3] = boardCorners[1].y;
    a[4] = boardCorners[2].x;
    a[5] = boardCorners[2].y;
    a[6] = boardCorners[3].x;
    a[7] = boardCorners[3].y;
    
    
    
    cornersGlobal[0] = boardCorners[0].x;
    cornersGlobal[1] = boardCorners[0].y;
    cornersGlobal[2] = boardCorners[1].x;
    cornersGlobal[3] = boardCorners[1].y;
    cornersGlobal[4] = boardCorners[2].x;
    cornersGlobal[5] = boardCorners[2].y;
    cornersGlobal[6] = boardCorners[3].x;
    cornersGlobal[7] = boardCorners[3].y;
    
    
    
    // 0  1
    // 3  2
    
    // width between bottom two corners
    int width = boardCorners[2].x - boardCorners[3].x;
    
    for (i = 0; i < 4; i++) {
        printf("Point %d: x: %d y:%d\n", i, boardCorners[i].x, boardCorners[i].y);
    }
    
    printf("width: %d\n", width);
    return width;
}

+ (void) getHSVValuesfromRed:(double)r Green:(double)g Blue:(double)b H:(int*)H S:(int*)S V:(int*)V
{
    // UIImage to cv::Mat
    Mat matted(8,8,CV_8UC3,cv::Scalar(r,g,b));
    
    //Change colorspace to HSV
    Mat HSVMat;
    cvtColor(matted, HSVMat, CV_BGR2HSV);
    
    //Obtain the HSV value of first row and column
    Vec3b pixel = HSVMat.at<Vec3b>(1,1);
    *H = pixel[0];
    *S = pixel[1];
    *V = pixel[2];
}

+ (UIImage *)imageWithColor:(UIColor *)color andSize:(CGSize)size

{
    /*
    CGRect rect = CGRectMake(0.0f, 0.0f, size.width, size.height);
    
    UIGraphicsBeginImageContext(rect.size);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();*/
    
    
    CGSize imageSize = size;
    UIColor *fillColor = color;
    UIGraphicsBeginImageContextWithOptions(imageSize, YES, 0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    [fillColor setFill];
    CGContextFillRect(context, CGRectMake(0, 0, imageSize.width, imageSize.height));
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
    
}

+ (UIImage*) thresh:(UIImage*) src colorCase:(int)colorCase
{
    // UIImage to cv::Mat
    cv::Mat matted = [src CVMat3];
    
    // cv::Mat to IplImage
    IplImage copy = matted;
    IplImage* ret = &copy;
    
    
    // call thresh function
    ret = thresh(ret, colorCase);
    
    // IplImage to cv::Mat
    matted = cvarrToMat(ret);
    
    // cv::Mat to UIImage
    UIImage* thr = [UIImage imageWithCVMat:matted];
    
    
    //return UIImage
    return thr;
    
}



IplImage* custom_thresh(IplImage* img, int l_h, int l_s, int l_v, int h_h, int h_s, int h_v)
{
    //Convert the image into an HSV image
    IplImage * imgHSV = cvCreateImage(cvGetSize(img), 8, 3);
    cvCvtColor(img, imgHSV, CV_BGR2HSV);
    
    
    //New image that will hold the thresholded image
    IplImage * imgThreshed = cvCreateImage(cvGetSize(img), 8, 1);
    
    cvInRangeS(imgHSV, cvScalar(l_h, l_s, l_v), cvScalar(h_h, h_s, h_v), imgThreshed);
    
    //Release the temp HSV image and return this thresholded image
    cvReleaseImage(&imgHSV);
    return imgThreshed;
}

+ (UIImage*) thresh:(UIImage*)image WithValuesinRanges:(int) lo_h :(int)lo_s :(int)lo_v :(int)hi_h :(int)hi_s :(int)hi_v;
{
    // UIImage to cv::Mat
    cv::Mat matted = [image CVMat3];
    
    
    // cv::Mat to IplImage
    IplImage copy = matted;
    IplImage* ret = &copy;
    
    
    // call thresh function
    ret = custom_thresh(ret, lo_h, lo_s, lo_v, hi_h, hi_s, hi_v);
    
    // IplImage to cv::Mat
    matted = cvarrToMat(ret);
    
    // cv::Mat to UIImage
    UIImage* thr = [UIImage imageWithCVMat:matted];
    
    
    //return UIImage
    return thr;

}

void warp (cv::Mat src, cv::Mat dst, CvPoint corners[4]) {
    
    // Input Quadilateral or Image plane coordinates
    Point2f inputPoints[4];
    // Output Quadilateral or World plane coordinates
    Point2f outputPoints[4];
    
    
    // Lambda Matrix
    Mat lambda( 2, 4, CV_32FC1 );
    
    // Set the lambda matrix the same type and size as input
    lambda = Mat::zeros( src.rows, src.cols, src.type() );
    
    
    // The 4 points of the map, starting from top left corner and moving clockwise
    inputPoints[0] = Point2f( corners[0].x, corners[0].y);
    inputPoints[1] = Point2f( corners[1].x, corners[1].y);
    inputPoints[2] = Point2f( corners[2].x, corners[2].y);
    inputPoints[3] = Point2f( corners[3].x, corners[3].y);
    // The 4 points where the mapping is to be done , from top-left in clockwise order
    outputPoints[0] = Point2f( 0, 0 );
    outputPoints[1] = Point2f( dst.cols-1, 0);
    outputPoints[2] = Point2f( dst.cols-1, dst.rows-1);
    outputPoints[3] = Point2f( 0, dst.rows-1  );
    
    
    // Get the Perspective Transform Matrix i.e. lambda
    lambda = getPerspectiveTransform( inputPoints, outputPoints );
    // Apply the Perspective Transform just found to the src image
    cv::warpPerspective(src,dst,lambda,dst.size() );
    
}

+ (UIImage*) warp:(UIImage *)input destination_image:(UIImage *)output
{
    // convert input and output to cv::Mat
    cv::Mat src = [input CVMat3];
    cv::Mat dst = [output CVMat3];
    
    CvPoint corners[4];
    
    // put x,y coords of 4 corners into a CvPoint array for warping
    corners[0].x = a[0];
    corners[0].y = a[1];
    corners[1].x = a[2];
    corners[1].y = a[3];
    corners[2].x = a[4];
    corners[2].y = a[5];
    corners[3].x = a[6];
    corners[3].y = a[7];
    
    // warp function in stitching.cpp
    warp(src, dst, corners);
    
    
    // convert cv::Mat to UIImage
    UIImage* result = [UIImage imageWithCVMat:dst];
    
    return result;
}

@end

