//
//  ViewController.h
//  UITouchImage
//
//  Created by LTG_Ugrad on 4/9/15.
//  Copyright (c) 2015 LTG_Ugrad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIScrollViewDelegate,UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIGestureRecognizerDelegate>

//take a photo
- (IBAction)takePhoto:(UIButton *)sender;
- (UIColor *) GetCurrentPixelColorAtPoint:(CGPoint)point;
- (IBAction)UndoTap:(UIButton *)sender;
- (IBAction)RemoveAllHSV:(UIButton *)sender;

@property (strong, nonatomic) IBOutlet UIScrollView *TouchableImage;
@property (strong, nonatomic) IBOutlet UIImageView *InspectedColour;
@property (strong, nonatomic) IBOutlet UISegmentedControl *ColorSwitcher;
- (IBAction)SetMinMaxHSV:(UIButton *)sender;

@end

