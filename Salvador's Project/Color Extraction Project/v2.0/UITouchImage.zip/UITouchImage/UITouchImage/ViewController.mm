//
//  ViewController.m
//  UITouchImage
//
//  Created by LTG_Ugrad on 4/9/15.
//  Copyright (c) 2015 LTG_Ugrad. All rights reserved.
//

#import "ViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "UIImage+OpenCV.h"
#import "OpenCVMethods.h"
#import "CVWrapper.h"
@interface ViewController ()

@end

@implementation ViewController

UITapGestureRecognizer *singleTap; // tap that recognizes color extraction
UITapGestureRecognizer *doubleTap; // tap that recognizes switching to original image
UIImageView *img;
UIImage *originalImg;              // keeps track of original WARPED image (unwarped for testing purposes)
UIImage *Coloured;                 // image that displays the inspected colour extracted from a pixel
UIImage *mean_image;               // median filtered original image
@synthesize ColorSwitcher;


/** Struct used to keep track of BGR values **/
typedef struct BGR_List
{
    double b;
    double g;
    double r;
    double a;
    struct BGR_List* next;
}BGR_List;

BGR_List *RedSample   = NULL;
BGR_List *GreenSample = NULL;
BGR_List *BlueSample  = NULL;
BGR_List *BrownSample = NULL;
/** Struct used to keep track of BGR values **/

//A pair of Low and High Min and Max HSV Values used for Thresholding
typedef struct HSV
{
    int h;
    int s;
    int v;
}HSV;

typedef struct MinMaxHSV
{
    HSV *low;
    HSV *high;
}MinMaxHSV;


long int clickedSegment;

//inserts a new BGR Value to a  sample list
void insertNewBGR2(BGR_List* *list, double B, double G, double R, double A)
{
    if ( (*list) == NULL)
    {
        *list = (BGR_List*)malloc(sizeof(BGR_List));
        (*list)->b = B;
        (*list)->g = G;
        (*list)->r = R;
        (*list)->a = A;
        (*list)->next = NULL;
    }
    else
    {
        BGR_List *newColor = (BGR_List*)malloc(sizeof(BGR_List));
        newColor->b = B;
        newColor->g = G;
        newColor->r = R;
        newColor->a = A;
        newColor->next = (*list);
        (*list) = newColor;
    }
}

//deallocates the BGR Samples
void deallocateList(BGR_List* *list)
{
    while (*list != NULL)
    {
        printf("R - %lf, G - %lf, B - %lf, A - %lf\n\n",(*list)->r, (*list)->g, (*list)->b, (*list)->a);
        
        BGR_List* temp = *list;
        (*list) = (*list)->next;
        free(temp);
    }
    
    printf("\n");
}

void RemoveBGR(BGR_List* *list)
{
    if (*list == NULL)
    {
        return;
    }
    BGR_List* temp = *list;
    (*list) = (*list)->next;
    free(temp);
}

HSV *getHSVVal(BGR_List *list)
{
    //SIDE TRACK...
    //Obtain HSV values from OpenCV Mat equivalent image with changed colorspace
    int H;
    int S;
    int V;
    
    //UIColor *color = [UIColor colorWithRed:list->r green:list->g blue:list->b alpha:list->a];
    //UIImage *colouredImg = [OpenCVMethods imageWithColor:color andSize:CGSizeMake(8, 8)];
    
    
    HSV *entry = (HSV*) malloc(sizeof(HSV));
    [OpenCVMethods getHSVValuesfromRed:list->r Green:list->g Blue:list->b H:&H S:&S V:&V];
    entry->h = H;
    entry->s = S;
    entry->v = V;
    
    printf("Extracted-----\nH - %d\nS - %d\nV - %d \n\n", entry->h, entry->s, entry->v);
    
    return entry;
}

MinMaxHSV *GetMinMaxHSVfromSample(BGR_List* list)
{
    if (list == NULL)
    {
        printf("Given an empty list... nothing to sample\n");
        return NULL;
    }
    int BGR_entries = 1;
    
    //allocating space for the Min Max HSV combination
    MinMaxHSV *vals = (MinMaxHSV*) malloc(sizeof(MinMaxHSV));
    vals->high = (HSV*)malloc(sizeof(HSV));
    vals->low = (HSV*)malloc(sizeof(HSV));
    
    //Sampling only one entry and converting it to HSV format
    HSV *entry = getHSVVal(list);
    int l_h = entry->h;
    int l_s = entry->s;
    int l_v = entry->v;
    
    int h_h = entry->h;
    int h_s = entry->s;
    int h_v = entry->v;
    
    
    free(entry);
    list = list->next;
    
    //Continuing process if there are more BGR's in the List
    while (list != NULL)
    {
        entry = getHSVVal(list);
        
        //Determine if the new sampling has higher HSV values than the current max HSV value
        if  (h_h < entry->h)
        {
            h_h = entry->h;
            h_s = entry->s;
            h_v = entry->v;
        }
        
        //Determine if the new sampling has lower HSV values than the current min HSV value
        if  (l_h > entry->h)
        {
    
            l_h = entry->h;
            l_s = entry->s;
            l_v = entry->v;
        }
        
        //move on to the next value
        list = list->next;
        BGR_entries++;
        free(entry);
    }
    
    
    //if there was only one sampling, create a standard min and max bound
    if (BGR_entries == 1)
    {
        printf("I only have one value\n");
        vals->high->h = h_h;
        vals->high->s = 255;
        vals->high->v = 255;
        
        vals->low->h = l_h;
        vals->low->s = 0;
        vals->low->v = 0;
    }
    else
    {
        //swap the lower boundaries of the saturation and value values in case the lower bounds value is greater
        //than the upper bounds value (no real need to but gives an ok estimate range for sat and val)
        if (l_s >= h_s)
        {
            int temp_s = l_s;
            l_s = h_s;
            h_s = temp_s;
            
        }
        
        if (l_v >= h_v)
        {
            int temp_v = l_v;
            l_v = h_v;
            h_v = temp_v;
        }
        
        //logic that sets the high Saturation and Value values to midpoint from the recorded value and 255
        vals->high->h = h_h;
        vals->high->s = 255 - ((255 - h_s)/2);
        vals->high->v = 255 - ((255 - h_v)/2);;
        
        //logic that sets the low Saturation and Value values to midpoint from the recorded value and 0
        vals->low->h = l_h;
        vals->low->s = 0 + (l_s/2);
        vals->low->v = 0 + (l_v/2);

    }
    return vals;
}


- (UIColor *) GetCurrentPixelColorAtPoint:(CGPoint)point
{
    // Extract Colour
    unsigned char pixel[4] = {0};
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(pixel, 1, 1, 8, 4, colorSpace, kCGBitmapAlphaInfoMask & kCGImageAlphaPremultipliedLast);
    CGContextTranslateCTM(context, -point.x, -point.y);
    [self.TouchableImage.layer renderInContext:context];
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    
    UIColor *color = [UIColor colorWithRed:pixel[0]/255.0 green:pixel[1]/255.0 blue:pixel[2]/255.0 alpha:pixel[3]/255.0];
    
    //Save the BGR values of the pixel coordinates
    clickedSegment = ColorSwitcher.selectedSegmentIndex;
    
    switch (clickedSegment) {
        case 0:
            printf("Extracting Sample for the colour red!!!\n");
            insertNewBGR2(&RedSample,(double)pixel[2], (double)pixel[1], (double)pixel[0], (double)pixel[3]);
            break;
        case 1:
            printf("Extracting Sample for the colour green!!!\n");
            insertNewBGR2(&GreenSample,(double)pixel[2], (double)pixel[1], (double)pixel[0], (double)pixel[3]);
            break;
        case 2:
            printf("Extracting Sample for the colour blue!!!\n");
            insertNewBGR2(&BlueSample,(double)pixel[2], (double)pixel[1], (double)pixel[0], (double)pixel[3]);
            break;
        case 3:
            printf("Extracting Sample for the colour brown!!!\n");
            insertNewBGR2(&BrownSample,(double)pixel[2], (double)pixel[1], (double)pixel[0], (double)pixel[3]);
            break;
        default:
            break;
    }
    
    return color;
}

- (IBAction)UndoTap:(UIButton *)sender {
    
    clickedSegment = ColorSwitcher.selectedSegmentIndex;
    
    switch (clickedSegment) {
        case 0:
            printf("Removing Last Red Sample!!!\n");
            RemoveBGR(&RedSample);
            break;
        case 1:
            printf("Removing Last Green Sample!!!\n");
            RemoveBGR(&GreenSample);
            break;
        case 2:
            printf("Removing Last Blue Sample!!!\n");
            RemoveBGR(&BlueSample);
            break;
        case 3:
            printf("Removing Last Brown Sample!!!\n");
            RemoveBGR(&BrownSample);
            break;
        default:
            break;
    }
}

- (IBAction)RemoveAllHSV:(UIButton *)sender {
    
    clickedSegment = ColorSwitcher.selectedSegmentIndex;
    
    switch (clickedSegment)
    {
        case 0:
            deallocateList(&RedSample);
            break;
        case 1:
            deallocateList(&GreenSample);
            break;
        case 2:
            deallocateList(&BlueSample);
            break;
        case 3:
            deallocateList(&BrownSample);
            break;
        default:
            break;
    }
    
}

- (void) handleSingleTapFrom: (UITapGestureRecognizer *)recognizer
{
    CGPoint point =[singleTap locationInView:self.TouchableImage];
    
    UIColor * color = [self GetCurrentPixelColorAtPoint:point];
    self.InspectedColour.backgroundColor = color;
    Coloured = self.InspectedColour.image;
}

- (void) handleDoubleTapFrom: (UITapGestureRecognizer *) recognizer
{
    if (img != nil)
    {
        printf("Reseting to unthreshed image\n");
        [self setUpScrollView:mean_image];
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}


- (void) setUpScrollView: (UIImage *) newImg
{
    //MAKE SURE THAT IMAGE VIEW IS REMOVED IF IT EXISTS ON SCROLLVIEW!!
    if (img != nil)
    {
        [img removeFromSuperview];
        
    }
    
    img = [[UIImageView alloc] initWithImage:newImg];
    
    //handle pinching in/ pinching out to zoom
    img.userInteractionEnabled = YES;
    img.backgroundColor = [UIColor clearColor];
    img.contentMode =  UIViewContentModeCenter;
    //img.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    
    //add a tap gesture recognizer for extracting colour
    singleTap = [[UITapGestureRecognizer alloc]
                 initWithTarget:self
                 action:@selector(handleSingleTapFrom:)];
    singleTap.numberOfTapsRequired = 1;
    [img addGestureRecognizer:singleTap];
    singleTap.delegate = self;
    
    
    //add a tap gesture recognizer for zooming in
    doubleTap = [[UITapGestureRecognizer alloc]
                 initWithTarget:self
                 action:@selector(handleDoubleTapFrom:)];
    doubleTap.numberOfTapsRequired = 2;
    [img addGestureRecognizer:doubleTap];
    doubleTap.delegate = self;
    //Fail to implement single tap if double tap is met
    [singleTap requireGestureRecognizerToFail:doubleTap];
    
    
    self.TouchableImage.minimumZoomScale=0.5;
    self.TouchableImage.maximumZoomScale=15.0;
    self.TouchableImage.contentSize = CGSizeMake(img.frame.size.width+100, img.frame.size.height+100);
    self.TouchableImage.clipsToBounds = YES;
    self.TouchableImage.delegate = self;
    //self.TouchableImage.contentSize=CGSizeMake(1280, 960);
    
    //Set image on the scrollview
    [self.TouchableImage addSubview:img];
}


- (UIImage *) warpImage: (UIImage *) image
{
    int corners[8];
    
    UIImage* threshed = nil;
    threshed = [OpenCVMethods thresh:image colorCase: 6];
    
    
    //Contours
    int width = [OpenCVMethods detectContours:threshed corners:corners];
    
    if(width != 0) {
        width = abs(width);
    }
    else width = 1;
    
    
    //warp
    int height = (width * 23) / 25;
    
    // make blank image of size widthXheight
    UIImage *dst = nil;
    CGSize targetSize = CGSizeMake(width, height);
    UIGraphicsBeginImageContext(targetSize);
    
    CGRect thumbnailRect = CGRectMake(0, 0, 0, 0);
    thumbnailRect.origin = CGPointMake(0.0,0.0);
    thumbnailRect.size.width  = targetSize.width;
    thumbnailRect.size.height = targetSize.height;
    
    [image drawInRect:thumbnailRect];
    
    
    dst = UIGraphicsGetImageFromCurrentImageContext();
    
    
    UIGraphicsEndImageContext();
    // finished making image
    
    
    // make a UIImage which will be perspectively warped from stitchedImage
    // use stitchedImageGlobal because it is the global equivalent to stitchedImage
    UIImage* destination = [OpenCVMethods warp:image destination_image:dst];

    if (destination == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Image warping failed! \nPlease take your picture again" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        return nil;
    }
    
    return destination;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - scroll view delegate

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return img;
}

/** delegates the taking of a photo to the camera **/
- (IBAction)takePhoto:(UIButton *)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = NO;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    
    [self presentViewController:picker animated:YES completion:NULL];
}

/** What to do with image after its been picked **/
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    UIImage* imageFromCam = info[UIImagePickerControllerOriginalImage];
    
    //Generates a warped Image of the picture
    //UIImage* warpedImage = [self warpImage:imageFromCam];
    
    //If you want to implement warped image: locally saves image and median filtered image
    //originalImg = [UIImage imageWithCGImage:warpedImage.CGImage];
    //mean_image = [OpenCVMethods ApplyMedianFilter:warpedImage];
    
    //for testing purposes (doesnt apply a warp)
    originalImg = [UIImage imageWithCGImage:imageFromCam.CGImage];
    mean_image = [OpenCVMethods ApplyMedianFilter:imageFromCam];
    
    //Sets up new image to the scrollview
    [self setUpScrollView:mean_image];
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

/** Cancelled on taking a picture **/
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

//obtains the min and max HSV values for a particular color, thresholds the image and displays it
- (IBAction)SetMinMaxHSV:(UIButton *)sender {
    UIImage* threshedColour = nil;
    
    clickedSegment = ColorSwitcher.selectedSegmentIndex;
    switch (clickedSegment) {
        case 0:{
            if (RedSample == NULL)
            {
                UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Samples of red pieces not found: Please pick some samples" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
                [alert show];
            }
            
            MinMaxHSV *Red = GetMinMaxHSVfromSample(RedSample);
            
            //Only if there exists values to sample
            if (Red != NULL){
                printf("Red  -> Obtained a min HSV value of: (%d, %d,%d)\nObtained a max HSV value of: (%d, %d,%d)\n\n", Red->low->h, Red->low->s, Red->low->v, Red->high->h, Red->high->s, Red->high->v);
            
                threshedColour = [OpenCVMethods thresh:mean_image WithValuesinRanges:Red->low->h :Red->low->s :Red->low->v :Red->high->h :Red->high->s :Red->high->v];
            
                free(Red->low);
                free(Red->high);
                free(Red);
            }
            break;
        }
        case 1:
        {
            if (GreenSample == NULL)
            {
                UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Samples of green pieces not found: Please pick some samples" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
                [alert show];
            }
            
            MinMaxHSV *Green = GetMinMaxHSVfromSample(GreenSample);
            
            if (Green != NULL)
            {
                printf("Green -> Obtained a min HSV value of: (%d, %d,%d)\nObtained a max HSV value of: (%d, %d,%d)\n\n", Green->low->h, Green->low->s, Green->low->v, Green->high->h, Green->high->s, Green->high->v);
            
                threshedColour = [OpenCVMethods thresh:mean_image WithValuesinRanges:Green->low->h :Green->low->s :Green->low->v :Green->high->h :Green->high->s :Green->high->v];
            
                free(Green->low);
                free(Green->high);
                free(Green);
            }
            break;
        }
            
        case 2:
        {
            if (BlueSample == NULL)
            {
                UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Samples of blue pieces not found: Please pick some samples" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
                [alert show];
            }
            
            MinMaxHSV *Blue = GetMinMaxHSVfromSample(BlueSample);
            
            if (Blue != NULL)
            {
                printf("Blue -> Obtained a min HSV value of: (%d, %d,%d)\nObtained a max HSV value of: (%d, %d,%d)\n\n", Blue->low->h, Blue->low->s, Blue->low->v, Blue->high->h, Blue->high->s, Blue->high->v);
            
                threshedColour = [OpenCVMethods thresh:mean_image WithValuesinRanges:Blue->low->h :Blue->low->s :Blue->low->v :Blue->high->h :Blue->high->s :Blue->high->v];
            
                free(Blue->low);
                free(Blue->high);
                free(Blue);
            }
            break;
        }
        case 3:
        {
            if (BrownSample == NULL)
            {
                UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Samples of brown pieces not found: Please pick some samples" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
                [alert show];
            }
            
            MinMaxHSV *Brown = GetMinMaxHSVfromSample(BrownSample);
            
            if (Brown != NULL)
            {
                printf("Brown -> Obtained a min HSV value of: (%d, %d,%d)\nObtained a max HSV value of: (%d, %d,%d)\n\n", Brown->low->h, Brown->low->s, Brown->low->v, Brown->high->h, Brown->high->s, Brown->high->v);
            
                threshedColour = [OpenCVMethods thresh:mean_image WithValuesinRanges:Brown->low->h :Brown->low->s :Brown->low->v :Brown->high->h :Brown->high->s :Brown->high->v];
                
                free(Brown->low);
                free(Brown->high);
                free(Brown);
            }
            break;
        }
        default:
            break;
    }
    
    if (threshedColour != nil)
            [self setUpScrollView:threshedColour];
   
}
@end
