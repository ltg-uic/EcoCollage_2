//
//  OpenCVMethods.h
//  UITouchImage
//
//  Created by LTG_Ugrad on 4/10/15.
//  Copyright (c) 2015 LTG_Ugrad. All rights reserved.
//


#import "UIImage+OpenCV.h"

@interface OpenCVMethods : NSObject

+ (UIImage *) DrawnGrayScaleImage: (UIImage *) image;
+ (UIImage *) ApplyMedianFilter: (UIImage *) img;
+ (UIImage*) thresh:(UIImage*) src colorCase:(int)colorCase;
+ (int) detectContours:(UIImage *)src corners:(int[]) cornersGlobal;
+ (UIImage*) warp:(UIImage *)input destination_image:(UIImage *)output;
+ (UIImage*) thresh:(UIImage*)image WithValuesinRanges:(int) lo_h :(int)lo_s :(int)lo_v :(int)hi_h :(int)hi_s :(int)hi_v;
+ (void) getHSVValuesfromRed:(double)r Green:(double)g Blue:(double)b H:(int*)H S:(int*)S V:(int*)V;
+ (UIImage *)imageWithColor:(UIColor *)color andSize:(CGSize)size;
@end



