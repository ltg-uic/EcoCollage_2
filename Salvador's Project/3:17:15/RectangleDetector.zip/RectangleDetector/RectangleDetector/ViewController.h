//
//  ViewController.h
//  RectangleDetector
//
//  Created by LTG_Ugrad on 3/3/15.
//  Copyright (c) 2015 LTG_Ugrad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIImageView *ImageWithPoints;
@property (strong, nonatomic) IBOutlet UIImageView *Image1;

- (IBAction)DeterminePoints:(UIButton *)sender;
- (UIImage *)UIImageFromIplImage:(IplImage *)image;
- (IplImage *)CreateIplImageFromUIImage:(UIImage *)image;

@end

