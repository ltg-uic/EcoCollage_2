//
//  APPViewController.m
//  HelloOpenCV
//
//  Created by LTG_Ugrad on 2/12/15.
//  Copyright (c) 2015 LTG_Ugrad. All rights reserved.
//

#import "APPViewController.h"
#import <opencv2/opencv.hpp>
#import "UIImage+OpenCV.h"
#import <opencv2/stitching/stitcher.hpp>

@interface APPViewController ()

@end

@implementation APPViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    UIImage* testImg1  = [UIImage imageNamed:@"002.jpg"];
    UIImage* testImg2  = [UIImage imageNamed:@"003.jpg"];
    cv::vector<cv::Mat> images;
    
    images.push_back([testImg1 CVMat]);
    images.push_back([testImg2 CVMat]);
    
    cv::Stitcher stitcher = cv::Stitcher::createDefault(YES);
    /*
    cv::Stitcher::Status st1 = stitcher.stitch(images, imgResult);
    /////////add image to uiimageview
    UIImage *image=  [self UIImageFromCVMat:imgResult];
    imgView.image=image;*/
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
