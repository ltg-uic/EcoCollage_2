//
//  ViewController.m
//  RectangleDetector
//
//  Created by LTG_Ugrad on 3/3/15.
//  Copyright (c) 2015 LTG_Ugrad. All rights reserved.
//

#import "ViewController.h"
#import <opencv2/opencv.hpp>
#import <opencv2/highgui/ios.h>
#import "CVWrapper.h"
#import "UIImage+OpenCV.h"

using namespace cv;


@interface ViewController ()

@end

NSString* mapimg = @"Map1.JPG";  //name of the picture to be processed

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.Image1.image = [UIImage imageNamed: mapimg];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


// NOTE You should convert color mode as RGB before passing to this function
- (UIImage *)UIImageFromIplImage:(IplImage *)image {
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    // Allocating the buffer for CGImage
    NSData *data =
    [NSData dataWithBytes:image->imageData length:image->imageSize];
    CGDataProviderRef provider =
    CGDataProviderCreateWithCFData((CFDataRef)data);
    // Creating CGImage from chunk of IplImage
    CGImageRef imageRef = CGImageCreate(
                                        image->width, image->height,
                                        image->depth, image->depth * image->nChannels, image->widthStep,
                                        colorSpace, kCGImageAlphaNone|kCGBitmapByteOrderDefault,
                                        provider, NULL, false, kCGRenderingIntentDefault
                                        );
    // Getting UIImage from CGImage
    UIImage *ret = [UIImage imageWithCGImage:imageRef];
    CGImageRelease(imageRef);
    CGDataProviderRelease(provider);
    CGColorSpaceRelease(colorSpace);
    return ret;
}

// NOTE you SHOULD cvReleaseImage() for the return value when end of the code.
- (IplImage *)CreateIplImageFromUIImage:(UIImage *)image {
    // Getting CGImage from UIImage
    CGImageRef imageRef = image.CGImage;
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    // Creating temporal IplImage for drawing
    IplImage *iplimage = cvCreateImage(
                                       cvSize(image.size.width,image.size.height), IPL_DEPTH_8U, 4
                                       );
    // Creating CGContext for temporal IplImage
    CGContextRef contextRef = CGBitmapContextCreate(
                                                    iplimage->imageData, iplimage->width, iplimage->height,
                                                    iplimage->depth, iplimage->widthStep,
                                                    colorSpace, kCGImageAlphaPremultipliedLast|kCGBitmapByteOrderDefault
                                                    );
    // Drawing CGImage to CGContext
    CGContextDrawImage(
                       contextRef,
                       CGRectMake(0, 0, image.size.width, image.size.height),
                       imageRef
                       );
    CGContextRelease(contextRef);
    CGColorSpaceRelease(colorSpace);
    
    // Creating result IplImage
    IplImage *ret = cvCreateImage(cvGetSize(iplimage), IPL_DEPTH_8U, 3);
    cvCvtColor(iplimage, ret, CV_RGBA2BGR);
    cvReleaseImage(&iplimage);
    
    return ret;
}


cv::Point2f computeIntersect(cv::Vec4i a, cv::Vec4i b)
{
    
    int x1 = a[0], y1 = a[1], x2 = a[2], y2 = a[3];
    int x3 = b[0], y3 = b[1], x4 = b[2], y4 = b[3];
    
    if (float d = ((float)(x1-x2) * (y3-y4)) - ((y1-y2) * (x3-x4)))
    {
        cv::Point2f pt;
        pt.x = ((x1*y2 - y1*x2) * (x3-x4) - (x1-x2) * (x3*y4 - y3*x4)) / d;
        pt.y = ((x1*y2 - y1*x2) * (y3-y4) - (y1-y2) * (x3*y4 - y3*x4)) / d;
        return pt;
    }
    else
        return cv::Point2f(-1, -1);
}


void sortCorners(std::vector<cv::Point2f>& corners,
                 cv::Point2f center)
{
    std::vector<cv::Point2f> top, bot;
    
    for (int i = 0; i < corners.size(); i++)
    {
        if (corners[i].y < center.y)
            top.push_back(corners[i]);
        else
            bot.push_back(corners[i]);
    }
    corners.clear();
    
    if (top.size() == 2 && bot.size() == 2){
        cv::Point2f tl = top[0].x > top[1].x ? top[1] : top[0];
        cv::Point2f tr = top[0].x > top[1].x ? top[0] : top[1];
        cv::Point2f bl = bot[0].x > bot[1].x ? bot[1] : bot[0];
        cv::Point2f br = bot[0].x > bot[1].x ? bot[0] : bot[1];
        
        
        corners.push_back(tl);
        corners.push_back(tr);
        corners.push_back(br);
        corners.push_back(bl);
    }
}


/** helper function for thresh_callback **/
/** Give a look at http://opencv-code.com/tutorials/detecting-simple-shapes-in-an-image/ **/

static double angle(cv::Point pt1, cv::Point pt2, cv::Point pt0)
{
    double dx1 = pt1.x - pt0.x;
    double dy1 = pt1.y - pt0.y;
    double dx2 = pt2.x - pt0.x;
    double dy2 = pt2.y - pt0.y;
    return (dx1*dx2 + dy1*dy2)/sqrt((dx1*dx1 + dy1*dy1)*(dx2*dx2 + dy2*dy2) + 1e-10);
}

void setLabel(cv::Mat& im, const std::string label, std::vector<cv::Point>& contour)
{
    int fontface = cv::FONT_HERSHEY_SIMPLEX;
    double scale = 0.4;
    int thickness = 1;
    int baseline = 0;
    
    cv::Size text = cv::getTextSize(label, fontface, scale, thickness, &baseline);
    cv::Rect r = cv::boundingRect(contour);
    
    cv::Point pt(r.x + ((r.width - text.width) / 2), r.y + ((r.height + text.height) / 2));
    cv::rectangle(im, pt + cv::Point(0, baseline), pt + cv::Point(text.width, -text.height), CV_RGB(255,255,255), CV_FILLED);
    cv::putText(im, label, pt, fontface, scale, CV_RGB(0,0,0), thickness, 8);
}


/** Attempt at drawing the contour with the largest area **/
Mat DetectAndDrawQuads(cv::Mat Img, cv::Mat threshedImg)
{
    int largest_area=0;
    int largest_contour_index=0;
    
    cv::Rect bounding_rect;
    Mat dst(Img.rows,Img.cols,CV_8UC1,Scalar::all(0));
    
    
    vector<vector<cv::Point>> contours; // Vector for storing contour
    vector<Vec4i> hierarchy;
    
    findContours( threshedImg, contours, hierarchy,CV_RETR_CCOMP, CV_CHAIN_APPROX_SIMPLE ); // Find the contours in the image
    
    for( int i = 0; i< contours.size(); i++ ) // iterate through each contour.
    {
        double a = contourArea( contours[i],false);  //  Find the area of contour
        if(a > largest_area){
            largest_area=a;
            largest_contour_index=i;                //Store the index of largest contour
            bounding_rect=boundingRect(contours[i]); // Find the bounding rectangle for biggest contour
        }
        
    }
    
    Scalar color( 255,255,255);
    drawContours( dst, contours,largest_contour_index, color, CV_FILLED, 8, hierarchy ); // Draw the largest contour using previously stored index.
    
    rectangle(Img, bounding_rect,  Scalar(0,255,0),1, 8,0);
    return Img;
}

/** draws all contours in different colours**/
Mat thresh_callback(Mat threshedImg)
{
    RNG rng(12345);
    
    int thresh = 100;
    Mat canny_output;
    vector<vector<cv::Point> > contours;
    vector<Vec4i> hierarchy;
    // The array for storing the approximation curve
    std::vector<cv::Point> approx;

    /// Detect edges using canny
    Canny( threshedImg, canny_output, thresh, thresh*2, 3 );
    /// Find contours
    findContours( canny_output, contours, hierarchy, CV_RETR_EXTERNAL , CV_CHAIN_APPROX_SIMPLE, cv::Point(0, 0) );
    
    /// Draw contours
    Mat drawing = Mat::zeros( canny_output.size(), CV_8UC3 );
    std::cout<<"There are "<<contours.size()<<" contours"<<std::endl;
    
    for( int i = 0; i< contours.size(); i++ )
    {
        // Approximate contour with accuracy proportional
        // to the contour perimeter
        cv::approxPolyDP(
                         cv::Mat(contours[i]),
                         approx,
                         cv::arcLength(cv::Mat(contours[i]), true) * 0.02,
                         true
                         );
        
        // Skip small or non-convex objects
        if (std::fabs(cv::contourArea(contours[i])) < 100 || !cv::isContourConvex(approx))
            continue;
        
        else if (approx.size() >= 4 && approx.size() <= 6)
        {
            // Number of vertices of polygonal curve
            int vtc = approx.size();
            
            // Get the degree (in cosines) of all corners
            std::vector<double> cos;
            for (int j = 2; j < vtc+1; j++)
                cos.push_back(angle(approx[j%vtc], approx[j-2], approx[j-1]));
            
            // Sort ascending the corner degree values
            std::sort(cos.begin(), cos.end());
            
            // Get the lowest and the highest degree
            double mincos = cos.front();
            double maxcos = cos.back();
            
            // Use the degrees obtained above and the number of vertices
            // to determine the shape of the contour
            if (vtc == 4 && mincos >= -0.1 && maxcos <= 0.3)
            {
                Scalar color = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
                drawContours( drawing, contours, i, color, 2, 8, hierarchy, 0, cv::Point() );
            }
        }
        
    }
    
    return drawing;
}

Mat detectRectangles(Mat img)
{
    Mat src;
    Mat gray;
    img.copyTo(src);
    img.copyTo(gray);
    
    
    // Convert to grayscale
    cvtColor(src, gray, CV_BGR2GRAY);
    
    // Convert to binary image using Canny
    Mat bw;
    Canny(gray, bw, 0, 50, 5);
    
    // Find contours
    vector<std::vector<cv::Point> > contours;
    findContours(bw.clone(), contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);
    
    // The array for storing the approximation curve
    vector<cv::Point> approx;
    
    // We'll put the labels in this destination image
    Mat dst = src.clone();
    
    for (int i = 0; i < contours.size(); i++)
    {
        // Approximate contour with accuracy proportional
        // to the contour perimeter
        cv::approxPolyDP(
                         cv::Mat(contours[i]),
                         approx,
                         cv::arcLength(cv::Mat(contours[i]), true) * 0.02,
                         true
                         );
        

        
        if (approx.size() >= 4 && approx.size() <= 6)
        {
            // Number of vertices of polygonal curve
            int vtc = approx.size();
            
            // Get the degree (in cosines) of all corners
            std::vector<double> cos;
            for (int j = 2; j < vtc+1; j++)
                cos.push_back(angle(approx[j%vtc], approx[j-2], approx[j-1]));
            
            // Sort ascending the corner degree values
            std::sort(cos.begin(), cos.end());
            
            // Get the lowest and the highest degree
            double mincos = cos.front();
            double maxcos = cos.back();
            
            // Use the degrees obtained above and the number of vertices
            // to determine the shape of the contour
            if (vtc == 4 && mincos >= -0.1 && maxcos <= 0.3)
            {
                // Detect rectangle or square
                cv::Rect r = cv::boundingRect(contours[i]);
                double ratio = std::abs(1 - (double)r.width / r.height);
                
                setLabel(dst, ratio <= 0.02 ? "SQU" : "RECT", contours[i]);
            }
        }
        
    }
    return src;
}

- (IBAction)DeterminePoints:(UIButton *)sender {
    
    UIImage* img =  [UIImage imageNamed: mapimg];
    Mat src;
    Mat threshed;
    Mat canny_output;
    Point2f center(0,0);
    UIImageToMat(img, src);
    
    
    /** Thresholding the image to Binary**/
    UIImageToMat(img, threshed);
    blur( threshed, threshed, cv::Size(3,3) );
    cvtColor(threshed, threshed, CV_RGB2GRAY);
    threshold(threshed, threshed, 100, 255, THRESH_BINARY);
    //Canny(threshed, canny_output, 0, 50, 5);
    
    //attempting to find quad of map
    Mat finalImg;
    //finalImg = DetectAndDrawQuads(src, threshed);
    //finalImg = thresh_callback(threshed);
    //finalImg = detectRectangles(src);
    
    /** Ryan... threshed is the image that will give the black borders... the methods above just use it as a parameter **/
    self.ImageWithPoints.image = MatToUIImage(finalImg);
    
    
}
@end
