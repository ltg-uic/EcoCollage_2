//
//  AppViewController.h
//  TestImageStitcher
//
//  Created by LTG_Ugrad on 2/19/15.
//  Copyright (c) 2015 LTG_Ugrad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIImageView *FirstView;
@property (strong, nonatomic) IBOutlet UIImageView *SecondView;
@property (strong, nonatomic) IBOutlet UIImageView *StitchedView;
- (IBAction)showStitchedImage:(UIButton *)sender;

@end
