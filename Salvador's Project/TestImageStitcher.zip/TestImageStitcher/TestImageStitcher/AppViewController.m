//
//  AppViewController.m
//  TestImageStitcher
//
//  Created by LTG_Ugrad on 2/19/15.
//  Copyright (c) 2015 LTG_Ugrad. All rights reserved.
//

#import "AppViewController.h"
#import <opencv2/opencv.hpp>
#import <opencv2/highgui/ios.h>
#import "CVWrapper.h"

using namespace cv;

//Since the generate button will only be pushed once
bool pushedButton = false;

@interface AppViewController ()
@end

@implementation AppViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    //Initially render the two un-stitched images
    UIImage* img1 = [UIImage imageNamed:@"photo 4.jpg"];
    UIImage* img2 = [UIImage imageNamed:@"photo 5.jpg"];
    
     _FirstView.image = img1;
    _SecondView.image = img2;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) stitch
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        
        NSArray* imageArray = [NSArray arrayWithObjects:
                               [UIImage imageNamed:@"photo 4.jpg"]
                               ,[UIImage imageNamed:@"photo 5.jpg"]
                               , nil];
        
        UIImage* stitchedImage = [CVWrapper processWithArray:imageArray];
        dispatch_async(dispatch_get_main_queue(), ^{
            
            NSLog (@"stitchedImage %@",stitchedImage);
            _StitchedView.image = stitchedImage;
           
           
        });
    });
}


- (IBAction)showStitchedImage:(UIButton *)sender {
    
    if (!pushedButton){
        [self stitch];
        pushedButton = true;
    }
    else{
        UIAlertView* mes=[[UIAlertView alloc] initWithTitle:@"Picture is already stitched."
                                                    message:@"Calm down lel. 2spooky5um9?" delegate:self cancelButtonTitle:@"k love sozz lel" otherButtonTitles: nil];
        [mes show];
    }
}
@end
