//
//  APPViewController.m
//  Camera
//
//  Modified by LTG_Ugrad on 2/10/15.
//  Copyright (c) 2015 LTG_Ugrad. All rights reserved.
//
//  Original Author:
// http://www.appcoda.com/ios-programming-camera-iphone-app/

#import "APPViewController.h"

@interface APPViewController ()

@end

@implementation APPViewController

// last button pressed (either 1 or 2)
// "Take Photo" and "Select Photo" = 1
// "Take Photo 2" and "Select Photo 2" = 2
int last_pressed = 0;

int image_location = 1;

bool should_save = 0;
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        
        UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                              message:@"Device has no camera"
                                                             delegate:nil
                                                    cancelButtonTitle:@"OK"
                                                    otherButtonTitles: nil];
        
        [myAlertView show];
    }
    
    
    
    
}


- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
}


- (IBAction)takePhoto:(UIButton *)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    last_pressed = 1;
    should_save = 1;
    [self presentViewController:picker animated:YES completion:NULL];
}

- (IBAction)selectPhoto:(UIButton *)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    last_pressed = 1;
    should_save = 0;
    [self presentViewController:picker animated:YES completion:NULL];
    
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    
    
    switch(image_location){
        case 1: self.imageView.image = chosenImage;
            image_location++;
            break;
        case 2: self.imageView2.image = chosenImage;
            image_location++;
            break;
        case 3: self.imageView3.image = chosenImage;
            image_location++;
            break;
        case 4: self.imageView4.image = chosenImage;
            image_location = 1;
            break;
    }
    
    // if user clicked "take photo", it should save photo
    // if user clicked "select photo", it should not save photo
    if (should_save){
        UIImageWriteToSavedPhotosAlbum(chosenImage, nil, nil, nil);
    }
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}


@end
