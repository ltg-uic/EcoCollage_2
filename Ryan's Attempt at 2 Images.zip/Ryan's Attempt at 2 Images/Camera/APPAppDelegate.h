//
//  APPAppDelegate.h
//  Camera
//
//  Created by LTG_Ugrad on 2/10/15.
//  Copyright (c) 2015 LTG_Ugrad. All rights reserved.
//

#import <UIKit/UIKit.h>

@class APPViewController;

@interface APPAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) APPViewController *viewController;

@end
