//
//  CVWrapper.m
//  CVOpenTemplate
//
//  Created by Washe on 02/01/2013.
//  Copyright (c) 2013 foundry. All rights reserved.
//

#import "CVWrapper.h"
#import "UIImage+OpenCV.h"
#import "stitching.h"
    //#import <vector>


@implementation CVWrapper

int calibrate = 0;

+ (UIImage*) processImageWithOpenCV: (UIImage*) inputImage
{
    NSArray* imageArray = [NSArray arrayWithObject:inputImage];
    UIImage* result = [[self class] processWithArray:imageArray];
    return result;
}

+ (UIImage*) processWithOpenCVImage1:(UIImage*)inputImage1 image2:(UIImage*)inputImage2;
{
    NSArray* imageArray = [NSArray arrayWithObjects:inputImage1,inputImage2,nil];
    UIImage* result = [[self class] processWithArray:imageArray];
    return result;
}


+ (UIImage*) processWarp:(UIImage *)input destination_image:(UIImage *)output
{
    printf("test 1.1\n");
    // convert input and output to cv::Mat
    cv::Mat src = [input CVMat3];
    cv::Mat dst = [output CVMat3];
    printf("test 1.2\n");
    // warp function in stitching.cpp
    cv::Point2f inputPts[4];
    
    // get thresholded image
    // find points on thresholded image
    // put points into inputPts
    
    warp(src, dst, *inputPts);
    printf("test 1.3\n");
    
    // convert cv::Mat to UIImage
    UIImage* result =  [UIImage imageWithCVMat:dst];
    return result;
}



+ (int) getWidth:(UIImage *)src
{
    int width = 0;
    
    
    //** convert UIImage to IplImage
    IplImage* Iplsrc;
    
    Iplsrc = GetThresholdedImage(Iplsrc, 4);
    
    //** find two bottom-most points (2 points with highest y values
    // these two points are bottom corners of map
    // to get width, subtract x-value of the on with smaller x-value from x-value of other point
    cv::Point2f BLCorner, BRCorner;
    
    
    
    float x_BL = BLCorner.x;
    float x_BR = BRCorner.x;
    
    
    
    width = x_BR - x_BL;
    
    return width;
}

//Thresholding function
+ (IplImage*) GetThresholdedImage:(IplImage*) img colorCase:(int) colorCase
{
    //Convert the image into an HSV image
    IplImage * imgHSV = cvCreateImage(cvGetSize(img), 8, 3);
    cvCvtColor(img, imgHSV, CV_BGR2HSV);
    
    //New image that will hold the thresholded image
    IplImage * imgThreshed = cvCreateImage(cvGetSize(img), 8, 1);
    
    //*******************************Projector On***************************************//
    //**	white
    //		cvInRangeS(imgHSV, cvScalar(0, 0, 0), cvScalar(20, 55, 255), imgThreshed);
    //**	white on black
    //		cvInRangeS(imgHSV, cvScalar(0, 0, 200), cvScalar(360, 40, 255), imgThreshed);
    //**	red
    //		cvInRangeS(imgHSV, cvScalar(0, 100, 50), cvScalar(15, 200, 150), imgThreshed);
    //**	orange
    //		cvInRangeS(imgHSV, cvScalar(10, 100, 0), cvScalar(30, 250, 175), imgThreshed);
    //**	green
    //		cvInRangeS(imgHSV, cvScalar(30, 50, 50), cvScalar(90, 200, 130), imgThreshed);
    //**	wood
    //		cvInRangeS(imgHSV, cvScalar(10, 50, 120), cvScalar(30, 100, 165), imgThreshed);
    //**	blue
    //		cvInRangeS(imgHSV, cvScalar(90, 0, 40), cvScalar(150, 90, 130), imgThreshed);
    //**	black
    //		cvInRangeS(imgHSV, cvScalar(0, 0, 0), cvScalar(180, 190, 90), imgThreshed);
    
    
    //*******************************Projector Off***************************************//
    //**	black on white
    //		cvInRangeS(imgHSV, cvScalar(0, 0, 0), cvScalar(20, 55, 255), imgThreshed);
    //**	red
    //		cvInRangeS(imgHSV, cvScalar(0, 100, 50), cvScalar(15, 255, 130), imgThreshed);
    //**	orange
    //		cvInRangeS(imgHSV, cvScalar(5, 100, 60), cvScalar(30, 225, 130), imgThreshed);
    //**	green
    //		cvInRangeS(imgHSV, cvScalar(40, 75, 50), cvScalar(90, 255, 150), imgThreshed);
    //**	wood
    //		cvInRangeS(imgHSV, cvScalar(15, 60, 90), cvScalar(60, 200, 200), imgThreshed);
    //**	blue
    //		cvInRangeS(imgHSV, cvScalar(90, 90, 20), cvScalar(150, 200, 90), imgThreshed);
    //**	black
    //		cvInRangeS(imgHSV, cvScalar(0, 0, 0), cvScalar(100, 200, 30), imgThreshed);
    //**	silicon blue
    //		cvInRangeS(imgHSV, cvScalar(90, 100, 50), cvScalar(150, 220, 120), imgThreshed);
    
    //*************NEW******************Projector Off*********************COLORS******************//
    
    switch(colorCase){
            //**	red
        case 1 :
            cvInRangeS(imgHSV, cvScalar(0, 100, 90), cvScalar(20, 220, 255), imgThreshed);
            break;
            //**	blue
        case 3:
            cvInRangeS(imgHSV, cvScalar(90, 50, 40), cvScalar(150, 200, 200), imgThreshed);
            break;
            //**	green
        case 0:
            cvInRangeS(imgHSV, cvScalar(40, 35, 40), cvScalar(90, 255, 115), imgThreshed);
            break;
            //**	wood
        case 2:
            cvInRangeS(imgHSV, cvScalar(15, 60, 90), cvScalar(40, 200, 200), imgThreshed);
            break;
            //**    black
        case 4:
            cvInRangeS(imgHSV, cvScalar(0, 0, 0), cvScalar(255, 255, 40), imgThreshed);
            break;
    }
    
    //Release the temp HSV image and return this thresholded image
    cvReleaseImage(&imgHSV);
    return imgThreshed;
}


int DetectAndDrawQuads(IplImage * img, IplImage * original, int frameNumber, int colorCase, bool simulate)
{
    CvSeq * contours;
    CvSeq * result;
    CvMemStorage * storage = cvCreateMemStorage(0);
    IplImage * ret = cvCreateImage(cvGetSize(img), 8, 3);
    IplImage * temp = cvCloneImage(img);
    IplImage * oriTemp = cvCloneImage(original);
    
    //	symbolList[frameNumber].clear();
    int count = 0;
    int numPieces = 0;
    cvFindContours(temp, storage, &contours, sizeof(CvContour), CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE, cvPoint(0,0));
    while(contours)
    {
        
        result = cvApproxPoly(contours, sizeof(CvContour), storage, CV_POLY_APPROX_DP, cvContourPerimeter(contours) * 0.02, 0);
        if(result->total>=4 && fabs(cvContourArea(result, CV_WHOLE_SEQ)) > 20)
        {
            
            CvPoint * pt[result->total];
            for(int i=0;i < result->total; i++)
                pt[i] = (CvPoint * )cvGetSeqElem(result, i);
            int minX = temp->width;
            int minY = temp->height;
            int maxX = 0;
            int maxY = 0;
            for(int j = 0; j < result->total; j++){
                if(pt[j]->x < minX) minX = pt[j]->x;
                if(pt[j]->x > maxX) maxX = pt[j]->x;
                if(pt[j]->y < minY) minY = pt[j]->y;
                if(pt[j]->y > maxY) maxY = pt[j]->y;
            }
            
            int w = abs(maxX-minX);
            int h = abs(maxY-minY);
            if( w > 10 & h > 10){
                cvResetImageROI(img);
                char *windowName = new char[20];
                sprintf(windowName, "Detected Object %d - %d ", colorCase, count);
                cvResetImageROI(oriTemp);
                
                count++;
                cvSetImageROI(oriTemp, cvRect(minX, minY, w, h));
                
                float xVal= ((maxX+minX) / 2.0) * (21.0/temp->width);
                float yVal = ((maxY+ minY)/ 2.0) * (25.0/temp->height);
                int x = ceil((maxX+minX) / 2.0) * (21.0/temp->width) + 1;
                int y = ceil((maxY+ minY)/ 2.0) * (25.0/temp->height);
                
                if(calibrate == 1){
                    //cvDestroyWindow(windowName);
                    //cvNamedWindow(windowName);
                    //cvShowImage(windowName, oriTemp);
                    printf("%d %f %f\n", colorCase, xVal, yVal);
                    printf("%d %d \n", x, y);
                }
                if((x>= 0 && x <= 22) && (y>=0 && y<= 24)){
                    if(simulate)
                        //    fprintf(outputRecord, "%d %d %d\n", colorCase, x, 24-y);
                        numPieces++;
                }
                //fprintf(trialFile, "%d %d %d\n", colorCase, x, 24-y);
                
                printf("%d %d %d\n", colorCase, x, 24-y);
            }
            
        }
        contours = contours -> h_next;
    }
    
    cvReleaseImage(&temp);
    cvReleaseMemStorage(&storage);
    return numPieces;
}





+ (UIImage*) processWithArray:(NSArray*)imageArray
{
    if ([imageArray count]==0){
        NSLog (@"imageArray is empty");
        return 0;
        }
    cv::vector<cv::Mat> matImages;

    for (id image in imageArray) {
        if ([image isKindOfClass: [UIImage class]]) {
            cv::Mat matImage = [image CVMat3];
            NSLog (@"matImage: %@",image);
            matImages.push_back(matImage);
        }
    }
    NSLog (@"stitching...");
    cv::Mat stitchedMat = stitch (matImages);
    UIImage* result =  [UIImage imageWithCVMat:stitchedMat];
    return result;
}


@end
