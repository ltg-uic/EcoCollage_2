//
//  CVWrapper.h
//  CVOpenTemplate
//
//  Created by Washe on 02/01/2013.
//  Copyright (c) 2013 foundry. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CVWrapper : NSObject

+ (UIImage*) processImageWithOpenCV: (UIImage*) inputImage;

+ (UIImage*) processWithOpenCVImage1:(UIImage*)inputImage1 image2:(UIImage*)inputImage2;

+ (UIImage*) processWithArray:(NSArray*)imageArray;

+ (UIImage*) processWarp:(UIImage*)src destination_image:(UIImage*) dst;

+ (int) getWidth:(UIImage*) src;

+ (IplImage*) GetThresholdedImage: (IplImage*) img colorCase: (int) colorCase;

+ (int) DetectAndDrawQuads: (IplImage*) img originalImage: (IplImage*) original frameNumber: (int) frameNumber colorCase: (int) colorCase simulateBool: (bool) simulate;

@end
