//
//  stitching.h
//  CVOpenTemplate
//
//  Created by Washe on 05/01/2013.
//  Copyright (c) 2013 Foundry. All rights reserved.
//

#ifndef CVOpenTemplate_Header_h
#define CVOpenTemplate_Header_h

cv::Mat stitch (cv::vector <cv::Mat> & images);
void warp (cv::Mat src, cv::Mat dst);
IplImage* thresh(IplImage* img, int colorCase);
int DetectAndDrawQuads(IplImage * img, IplImage * original, int frameNumber, int colorCase, bool simulate);

#endif
