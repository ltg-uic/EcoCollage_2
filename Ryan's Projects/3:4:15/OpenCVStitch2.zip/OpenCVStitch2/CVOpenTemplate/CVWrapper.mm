//
//  CVWrapper.m
//  CVOpenTemplate
//
//  Created by Washe on 02/01/2013.
//  Copyright (c) 2013 foundry. All rights reserved.
//

#import "CVWrapper.h"
#import "UIImage+OpenCV.h"
#import "stitching.h"
    //#import <vector>


@implementation CVWrapper

+ (UIImage*) processImageWithOpenCV: (UIImage*) inputImage
{
    NSArray* imageArray = [NSArray arrayWithObject:inputImage];
    UIImage* result = [[self class] processWithArray:imageArray];
    return result;
}

+ (UIImage*) processWithOpenCVImage1:(UIImage*)inputImage1 image2:(UIImage*)inputImage2;
{
    NSArray* imageArray = [NSArray arrayWithObjects:inputImage1,inputImage2,nil];
    UIImage* result = [[self class] processWithArray:imageArray];
    return result;
}


+ (int) detectContours:(UIImage *)src {
    int contours = 0;
    
    printf("test 0.1\n");
    
    // needed to make new image because next comment was causing conversion error
    UIImage *new_src = nil;
    CGSize targetSize = src.size;
    UIGraphicsBeginImageContext(targetSize);
    
    CGRect thumbnailRect = CGRectMake(0, 0, 0, 0);
    thumbnailRect.origin = CGPointMake(0.0,0.0);
    thumbnailRect.size.width  = targetSize.width;
    thumbnailRect.size.height = targetSize.height;
    
    [src drawInRect:thumbnailRect];
    
    
    new_src = UIGraphicsGetImageFromCurrentImageContext();
    
    
    UIGraphicsEndImageContext();
    
    // needed to make new image (new_src) because this was causing a conversion error
    cv::Mat mat_src = [new_src CVMat3];
    
    printf("test 0.2\n");
    IplImage copy_src = mat_src;
    IplImage* ipl_src = &copy_src;
    
    
    
    // convert to black and white image for cvFindContours
    // used in stitching.cpp function DetectAndDrawQuads
    
    printf("test 1\n");
    cv::Mat bwImage;
    cv::cvtColor(mat_src, bwImage, CV_RGB2GRAY);
    
    
    printf("test 2\n");
    copy_src = bwImage;
    ipl_src = &copy_src;
    
    IplImage* ipl_dst = ipl_src;
    
    printf("test 3\n");
    contours = DetectAndDrawQuads(ipl_src, ipl_dst, 5, 4, 0);
    
    
    return contours;
}

 + (UIImage*) warp:(UIImage *)input destination_image:(UIImage *)output
{
    // convert input and output to cv::Mat
    cv::Mat src = [input CVMat3];
    cv::Mat dst = [output CVMat3];
    
    // warp function in stitching.cpp
    warp(src, dst);
    
    // convert cv::Mat to UIImage
    UIImage* result =  [UIImage imageWithCVMat:dst];
    
    
    return result;
}


+ (UIImage*) thresh:(UIImage*) src colorCase:(int)colorCase
{
    // UIImage to cv::Mat
    cv::Mat matted = [src CVMat3];
    
    // cv::Mat to IplImage
    IplImage copy = matted;
    IplImage* ret = &copy;
 
    // call thresh function in stitching.cpp
    ret = thresh(ret, colorCase);
    
    // IplImage to cv::Mat
    matted = ret;

    // cv::Mat to UIImage
    UIImage* thr = [UIImage imageWithCVMat:matted];
    
    //return UIImage
    return thr;
    
    
}



+ (UIImage*) processWithArray:(NSArray*)imageArray
{
    if ([imageArray count]==0){
        NSLog (@"imageArray is empty");
        return 0;
        }
    cv::vector<cv::Mat> matImages;

    for (id image in imageArray) {
        if ([image isKindOfClass: [UIImage class]]) {
            cv::Mat matImage = [image CVMat3];
            NSLog (@"matImage: %@",image);
            matImages.push_back(matImage);
        }
    }
    NSLog (@"stitching...");
    cv::Mat stitchedMat = stitch (matImages);
    UIImage* result =  [UIImage imageWithCVMat:stitchedMat];
    return result;
}


@end
