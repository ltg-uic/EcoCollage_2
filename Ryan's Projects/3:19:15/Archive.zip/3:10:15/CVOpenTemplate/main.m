//
//  main.m
//  CVOpenTemplate
//
//  Created by jonathan on 02/01/2013.
//  Copyright (c) 2013 foundry. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CVAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CVAppDelegate class]));
    }
}
