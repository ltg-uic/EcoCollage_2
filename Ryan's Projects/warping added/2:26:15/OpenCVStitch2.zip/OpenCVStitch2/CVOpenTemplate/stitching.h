//
//  stitching.h
//  CVOpenTemplate
//
//  Created by Washe on 05/01/2013.
//  Copyright (c) 2013 Foundry. All rights reserved.
//

#ifndef CVOpenTemplate_Header_h
#define CVOpenTemplate_Header_h

cv::Mat stitch (cv::vector <cv::Mat> & images);
cv::Mat warp (cv::Mat src, cv::Mat dst);

#endif
