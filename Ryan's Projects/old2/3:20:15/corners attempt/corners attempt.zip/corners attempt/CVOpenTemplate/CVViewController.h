//
//  CVViewController.h
//  CVOpenTemplate
//
//  Created by Washe on 02/01/2013.
//  Copyright (c) 2013 foundry. All rights reserved.
//

//  EcoCollage 2015
//  Ryan Fogarty
//


#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface CVViewController : UIViewController <UINavigationControllerDelegate, UIImagePickerControllerDelegate>

@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *spinner;
@property (nonatomic, weak) IBOutlet UIImageView* imageView;
@property (strong, nonatomic) IBOutlet UIImageView *imageView2;
@property (strong, nonatomic) IBOutlet UIImageView *imageView3;
- (IBAction)takePhoto:(id)sender;
- (IBAction)stitchImages:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UITextView *textView;
- (IBAction)warp:(UIButton *)sender;
- (IBAction)threshold:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UITextView *cornersInfo;
- (IBAction)contours:(UIButton *)sender;
- (IBAction)analyze:(UIButton *)sender;
- (IBAction)saveImage:(UIButton *)sender;
- (IBAction)cornersOfBorder:(UIButton *)sender;

@property (nonatomic, weak) IBOutlet UIScrollView* scrollView;
@end
