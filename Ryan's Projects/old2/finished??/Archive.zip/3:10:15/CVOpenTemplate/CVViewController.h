//
//  CVViewController.h
//  CVOpenTemplate
//
//  Created by Washe on 02/01/2013.
//  Copyright (c) 2013 foundry. All rights reserved.
//

//  EcoCollage 2015
//  Ryan Fogarty
//  Salvador Ariza


#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface CVViewController : UIViewController <UINavigationControllerDelegate, UIImagePickerControllerDelegate>


@property (nonatomic, weak) IBOutlet UIImageView* imageView;
@property (strong, nonatomic) IBOutlet UIImageView *imageView2;
- (IBAction)takePhoto:(id)sender;
- (IBAction)incrementStudyNum:(UIButton *)sender;
- (IBAction)incrementTrialNum:(UIButton *)sender;


-(void)sendData;
-(void)processMap;
-(int)threshy;
-(int)contoury;
-(int)warpy;

- (IBAction)process:(UIButton *)sender;
- (IBAction)analyze:(UIButton *)sender;
- (IBAction)saveImage:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UITextField *studyNumber;
@property (strong, nonatomic) IBOutlet UITextField *trialNumber;
@property (strong, nonatomic) IBOutlet UITextField *IPAddress;



@property (nonatomic, weak) IBOutlet UIScrollView* scrollView;
- (IBAction)ClearUI:(UIButton *)sender;
@end
