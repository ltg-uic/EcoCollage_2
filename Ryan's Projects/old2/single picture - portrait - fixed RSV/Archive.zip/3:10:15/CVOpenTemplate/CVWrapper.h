//
//  CVWrapper.h
//  CVOpenTemplate
//
//  Created by Washe on 02/01/2013.
//  Copyright (c) 2013 foundry. All rights reserved.
//

//  EcoCollage 2015
//  Ryan Fogarty
//

#import <Foundation/Foundation.h>

@interface CVWrapper : NSObject

+ (UIImage*) warp:(UIImage*)src destination_image:(UIImage*) dst;

+ (UIImage*) thresh:(UIImage*) src colorCase:(int) colorCase;

+ (int) detectContours:(UIImage*) src corners:(int[]) corners;

+ (int) analysis:(UIImage*) src;

@end
