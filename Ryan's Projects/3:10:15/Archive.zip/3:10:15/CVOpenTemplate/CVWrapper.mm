//
//  CVWrapper.m
//  CVOpenTemplate
//
//  Created by Washe on 02/01/2013.
//  Copyright (c) 2013 foundry. All rights reserved.
//

#import "CVWrapper.h"
#import "UIImage+OpenCV.h"
#import "stitching.h"
    //#import <vector>
int a[8];

@implementation CVWrapper

+ (UIImage*) processImageWithOpenCV: (UIImage*) inputImage
{
    NSArray* imageArray = [NSArray arrayWithObject:inputImage];
    UIImage* result = [[self class] processWithArray:imageArray];
    return result;
}

+ (UIImage*) processWithOpenCVImage1:(UIImage*)inputImage1 image2:(UIImage*)inputImage2;
{
    NSArray* imageArray = [NSArray arrayWithObjects:inputImage1,inputImage2,nil];
    UIImage* result = [[self class] processWithArray:imageArray];
    return result;
}


+ (int) detectContours:(UIImage *)src corners:(int[]) cornersGlobal
{
    
    // needed to make new image because next comment was causing conversion error
    UIImage *new_src = nil;
    CGSize targetSize = src.size;
    UIGraphicsBeginImageContext(targetSize);
    
    CGRect thumbnailRect = CGRectMake(0, 0, 0, 0);
    thumbnailRect.origin = CGPointMake(0.0,0.0);
    thumbnailRect.size.width  = targetSize.width;
    thumbnailRect.size.height = targetSize.height;
    
    [src drawInRect:thumbnailRect];
    
    
    new_src = UIGraphicsGetImageFromCurrentImageContext();
    
    
    UIGraphicsEndImageContext();
    
    // needed to make new image (new_src) because this was causing a conversion error
    cv::Mat mat_src = [new_src CVMat3];
    
    IplImage copy_src = mat_src;
    IplImage* ipl_src = &copy_src;
    
    
    
    // convert to black and white image for cvFindContours
    // used in stitching.cpp function DetectAndDrawQuads
    
    cv::Mat bwImage;
    cv::cvtColor(mat_src, bwImage, CV_RGB2GRAY);
    
    
    copy_src = bwImage;
    ipl_src = &copy_src;
    
    IplImage* ipl_dst = ipl_src;

    //ERROR
    CvPoint pts[500];
    
    
    
    int ptsNumber = DetectAndDrawQuads(ipl_src, ipl_dst, pts, 5, 4, 0);
    
    int i = 0;
    //ERRORS OCCURRING
    //pts WITHOUT X OR Y VALUES FROM DetectAndDrawQuads
    //EVEN THOUGH EACH PT SHOULD HAVE BEEN POPULATED WITHIN THE FUNCTION
    while(i < ptsNumber) {
        int x = pts[i].x;
        int y = pts[i].y;
        printf("x: %d y: %d\n", x, y);
        i++;
    }
    
    // 0 1
    // 3 2
    CvPoint corners[4];
    corners[0] = cvPoint(1000, 1000);
    corners[1] = cvPoint(-1, 1000);
    corners[2] = cvPoint(-1, -1);
    corners[3] = cvPoint(1000, -1);
    
    int src_width = src.size.width;
    int src_height = src.size.height;
    
    
    
    // 0 1
    // 3 2
    for(i = 0; i < ptsNumber; i++) {
        if (pts[i].x > 20 && pts[i].y > 20 && pts[i].x < (src_width - 20) && pts[i].y < (src_height - 20)) {
        
            if(pts[i].x < corners[0].x && pts[i].y < corners[0].y) {
                corners[0] = pts[i];
            }
            if(pts[i].x > corners[1].x && pts[i].y < corners[1].y) {
                corners[1] = pts[i];
            }
            if(pts[i].x > corners[2].x && pts[i].y > corners[2].y) {
                corners[2] = pts[i];
            }
            if(pts[i].x < corners[3].x && pts[i].y > corners[3].y) {
                corners[3] = pts[i];
            }
        }
    }
    
    a[0] = corners[0].x;
    a[1] = corners[0].y;
    a[2] = corners[1].x;
    a[3] = corners[1].y;
    a[4] = corners[2].x;
    a[5] = corners[2].y;
    a[6] = corners[3].x;
    a[7] = corners[3].y;
    
    
    
    cornersGlobal[0] = corners[0].x;
    cornersGlobal[1] = corners[0].y;
    cornersGlobal[2] = corners[1].x;
    cornersGlobal[3] = corners[1].y;
    cornersGlobal[4] = corners[2].x;
    cornersGlobal[5] = corners[2].y;
    cornersGlobal[6] = corners[3].x;
    cornersGlobal[7] = corners[3].y;
    
    
    
    printf("%d %d\n", cornersGlobal[0], cornersGlobal[1]);

    
    // 0  1
    // 3  2
    
    int width = corners[2].x - corners[3].x;
    
    for (i = 0; i < 4; i++) {
        printf("Point %d: x: %d y:%d\n", i, corners[i].x, corners[i].y);
    }
    
    printf("width: %d\n", width);
    return width;
}

 + (UIImage*) warp:(UIImage *)input destination_image:(UIImage *)output
{
    // convert input and output to cv::Mat
    cv::Mat src = [input CVMat3];
    cv::Mat dst = [output CVMat3];
    
    CvPoint corners[4];
    
    corners[0].x = a[0];
    corners[0].y = a[1];
    corners[1].x = a[2];
    corners[1].y = a[3];
    corners[2].x = a[4];
    corners[2].y = a[5];
    corners[3].x = a[6];
    corners[3].y = a[7];
    
    // warp function in stitching.cpp
    warp(src, dst, corners);
    
    // convert cv::Mat to UIImage
    UIImage* result =  [UIImage imageWithCVMat:dst];
    
    
    return result;
}


+ (UIImage*) thresh:(UIImage*) src colorCase:(int)colorCase
{
    // UIImage to cv::Mat
    cv::Mat matted = [src CVMat3];
    
    // cv::Mat to IplImage
    IplImage copy = matted;
    IplImage* ret = &copy;
 
    // call thresh function in stitching.cpp
    ret = thresh(ret, colorCase);
    
    // IplImage to cv::Mat
    matted = ret;

    // cv::Mat to UIImage
    UIImage* thr = [UIImage imageWithCVMat:matted];
    
    //return UIImage
    return thr;
    
    
}



+ (UIImage*) processWithArray:(NSArray*)imageArray
{
    if ([imageArray count]==0){
        NSLog (@"imageArray is empty");
        return 0;
        }
    cv::vector<cv::Mat> matImages;

    for (id image in imageArray) {
        if ([image isKindOfClass: [UIImage class]]) {
            cv::Mat matImage = [image CVMat3];
            NSLog (@"matImage: %@",image);
            matImages.push_back(matImage);
        }
    }
    NSLog (@"stitching...");
    cv::Mat stitchedMat = stitch (matImages);
    UIImage* result =  [UIImage imageWithCVMat:stitchedMat];
    return result;
}


@end
