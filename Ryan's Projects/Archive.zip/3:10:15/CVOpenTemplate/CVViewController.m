//
//  CVViewController.m
//  CVOpenTemplate
//
//  Created by Washe on 02/01/2013.
//  Copyright (c) 2013 foundry. All rights reserved.

//  EcoCollage 2015
//  Ryan Fogarty
//  Salvador Ariza

#import "CVViewController.h"
#import "CVWrapper.h"
#import <math.h>
#import <stdlib.h>

@interface CVViewController ()
{
    NSArray *_hsvPickerData;
}


@end

@implementation CVViewController

NSString *fileContents;
NSURL *server;
NSString *IPAddress = @"131.193.79.217";
NSString *hsvStart, *hsvEnd;

int cornersGlobal[8];
int studyNumber;
int trialNumber;

/* HSV ranges for lab */
int hsvTests[] = {10, 50, 50, 80, 200, 255, 80, 140, 100, 175, 255, 255, 90, 40, 120, 110, 100, 225, 0, 30, 50, 15, 220, 210, 15, 35, 35, 90, 200, 130};
int hsvOrig[] = {10, 50, 50, 80, 200, 255, 80, 140, 100, 175, 255, 255, 90, 40, 120, 110, 100, 225, 0, 30, 50, 15, 220, 210, 15, 35, 35, 90, 200, 130};


int testBoy = 0;
int rowGlobal;


- (IBAction)IPAddress:(UITextField *)sender {
}
int widthGlobal = 0;

UIImage *userImage = nil;
UIImage *savedImage;
UIImage *threshedGlobal;
UIImage *warpedGlobal;
bool studyNum;

char results[5000];

- (void)viewDidAppear:(BOOL)animated    
{
    [super viewDidAppear:animated];
    
    _hsvPickerData = @[@"Swales", @"Barrels", @"Green Roofs", @"Permeable Pavers", @"Corner Markers"];
    
    // Connect data
    self.hsvPicker.dataSource = self;
    self.hsvPicker.delegate = self;
    
    self.IPAddress.text = IPAddress;

    NSString *text = [NSString stringWithFormat:@"Swales:\n(%d, %d, %d) - (%d, %d, %d)\n\nBarrels:\n(%d, %d, %d) - (%d, %d, %d)\n\nGreen Roofs:\n(%d, %d, %d) - (%d, %d, %d)\n\nPavers:\n(%d, %d, %d) - (%d, %d, %d)\n\nCorner Markers:\n(%d, %d, %d) - (%d, %d, %d)\n\nORIGINAL VALUES:\nSwales:\n(%d, %d, %d) - (%d, %d, %d)\n\nBarrels:\n(%d, %d, %d) - (%d, %d, %d)\n\nGreen Roofs:\n(%d, %d, %d) - (%d, %d, %d)\n\nPavers:\n(%d, %d, %d) - (%d, %d, %d)\n\nCorner Markers:\n(%d, %d, %d) - (%d, %d, %d)\n", hsvTests[0], hsvTests[1], hsvTests[2], hsvTests[3], hsvTests[4], hsvTests[5], hsvTests[6], hsvTests[7], hsvTests[8], hsvTests[9], hsvTests[10], hsvTests[11], hsvTests[12], hsvTests[13], hsvTests[14], hsvTests[15], hsvTests[16], hsvTests[17], hsvTests[18], hsvTests[19], hsvTests[20], hsvTests[21], hsvTests[22], hsvTests[23], hsvTests[24], hsvTests[25], hsvTests[26], hsvTests[27], hsvTests[28], hsvTests[29], hsvOrig[0], hsvOrig[1], hsvOrig[2], hsvOrig[3], hsvOrig[4], hsvOrig[5], hsvOrig[6], hsvOrig[7], hsvOrig[8], hsvOrig[9], hsvOrig[10], hsvOrig[11], hsvOrig[12], hsvOrig[13], hsvOrig[14], hsvOrig[15], hsvOrig[16], hsvOrig[17], hsvOrig[18], hsvOrig[19], hsvOrig[20], hsvOrig[21], hsvOrig[22], hsvOrig[23], hsvOrig[24], hsvOrig[25], hsvOrig[26], hsvOrig[27], hsvOrig[28], hsvOrig[29]];
    [self hsvValueInfo].text = text;
    
    // Do any additional setup after loading the view, typically from a nib.
    NSString *filepath = [[NSBundle mainBundle] pathForResource:@"Results" ofType:@"txt"];
    NSError *error;
    
    //this is the url you need to set to the output of the program
    fileContents = [NSString stringWithContentsOfFile:filepath encoding:NSUTF8StringEncoding error:&error];
    }


// The number of columns of data
- (int)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// The number of rows of data
- (int)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return _hsvPickerData.count;
}

// The data to return for the row and component (column) that's being passed in
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    //rowGlobal = component;
    return _hsvPickerData[row];
}

// Catpure the picker view selection
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    rowGlobal = row;
    // This method is triggered whenever the user makes a change to the picker selection.
    // The parameter named row and component represents what was selected.
}


- (IBAction)saveHSVValues:(UIButton *)sender {
    NSArray *arrStart = [hsvStart componentsSeparatedByString:@","];
    NSArray *arrEnd = [hsvEnd componentsSeparatedByString:@","];
    switch(rowGlobal) {
        case 0:
            hsvTests[0] = [[arrStart objectAtIndex:0] integerValue];
            hsvTests[1] = [[arrStart objectAtIndex:1] integerValue];
            hsvTests[2] = [[arrStart objectAtIndex:2] integerValue];
            hsvTests[3] = [[arrEnd objectAtIndex:0] integerValue];
            hsvTests[4] = [[arrEnd objectAtIndex:1] integerValue];
            hsvTests[5] = [[arrEnd objectAtIndex:2] integerValue];
            break;
        case 1:
            hsvTests[6] = [[arrStart objectAtIndex:0] integerValue];
            hsvTests[7] = [[arrStart objectAtIndex:1] integerValue];
            hsvTests[8] = [[arrStart objectAtIndex:2] integerValue];
            hsvTests[9] = [[arrEnd objectAtIndex:0] integerValue];
            hsvTests[10] = [[arrEnd objectAtIndex:1] integerValue];
            hsvTests[11] = [[arrEnd objectAtIndex:2] integerValue];
            break;
        case 2:
            hsvTests[12] = [[arrStart objectAtIndex:0] integerValue];
            hsvTests[13] = [[arrStart objectAtIndex:1] integerValue];
            hsvTests[14] = [[arrStart objectAtIndex:2] integerValue];
            hsvTests[15] = [[arrEnd objectAtIndex:0] integerValue];
            hsvTests[16] = [[arrEnd objectAtIndex:1] integerValue];
            hsvTests[17] = [[arrEnd objectAtIndex:2] integerValue];
            break;
        case 3:
            hsvTests[18] = [[arrStart objectAtIndex:0] integerValue];
            hsvTests[19] = [[arrStart objectAtIndex:1] integerValue];
            hsvTests[20] = [[arrStart objectAtIndex:2] integerValue];
            hsvTests[21] = [[arrEnd objectAtIndex:0] integerValue];
            hsvTests[22] = [[arrEnd objectAtIndex:1] integerValue];
            hsvTests[23] = [[arrEnd objectAtIndex:2] integerValue];
            break;
        case 4:
            hsvTests[24] = [[arrStart objectAtIndex:0] integerValue];
            hsvTests[25] = [[arrStart objectAtIndex:1] integerValue];
            hsvTests[26] = [[arrStart objectAtIndex:2] integerValue];
            hsvTests[27] = [[arrEnd objectAtIndex:0] integerValue];
            hsvTests[28] = [[arrEnd objectAtIndex:1] integerValue];
            hsvTests[29] = [[arrEnd objectAtIndex:2] integerValue];
            break;
        default:
            break;
    }
    NSString *text = [NSString stringWithFormat:@"Swales:\n(%d, %d, %d) - (%d, %d, %d)\n\nBarrels:\n(%d, %d, %d) - (%d, %d, %d)\n\nGreen Roofs:\n(%d, %d, %d) - (%d, %d, %d)\n\nPavers:\n(%d, %d, %d) - (%d, %d, %d)\n\nCorner Markers:\n(%d, %d, %d) - (%d, %d, %d)\n\nORIGINAL VALUES:\nSwales:\n(%d, %d, %d) - (%d, %d, %d)\n\nBarrels:\n(%d, %d, %d) - (%d, %d, %d)\n\nGreen Roofs:\n(%d, %d, %d) - (%d, %d, %d)\n\nPavers:\n(%d, %d, %d) - (%d, %d, %d)\n\nCorner Markers:\n(%d, %d, %d) - (%d, %d, %d)\n", hsvTests[0], hsvTests[1], hsvTests[2], hsvTests[3], hsvTests[4], hsvTests[5], hsvTests[6], hsvTests[7], hsvTests[8], hsvTests[9], hsvTests[10], hsvTests[11], hsvTests[12], hsvTests[13], hsvTests[14], hsvTests[15], hsvTests[16], hsvTests[17], hsvTests[18], hsvTests[19], hsvTests[20], hsvTests[21], hsvTests[22], hsvTests[23], hsvTests[24], hsvTests[25], hsvTests[26], hsvTests[27], hsvTests[28], hsvTests[29], hsvOrig[0], hsvOrig[1], hsvOrig[2], hsvOrig[3], hsvOrig[4], hsvOrig[5], hsvOrig[6], hsvOrig[7], hsvOrig[8], hsvOrig[9], hsvOrig[10], hsvOrig[11], hsvOrig[12], hsvOrig[13], hsvOrig[14], hsvOrig[15], hsvOrig[16], hsvOrig[17], hsvOrig[18], hsvOrig[19], hsvOrig[20], hsvOrig[21], hsvOrig[22], hsvOrig[23], hsvOrig[24], hsvOrig[25], hsvOrig[26], hsvOrig[27], hsvOrig[28], hsvOrig[29]];
    
    [self hsvValueInfo].text = text;
}

- (IBAction)testHSVValues:(UIButton *)sender {
    if(userImage == nil) return;
    
    UIImage *testImg;
    
    if(warpedGlobal == nil) {
        testImg = userImage;
    }
    else testImg = warpedGlobal;
    
    UIImage* threshed = nil;
    threshed = [CVWrapper thresh:testImg colorCase: rowGlobal hsvValues:hsvTests];
    
    //** following code shows thresholded image in scrollView
    UIImageView *imageView = [[UIImageView alloc] initWithImage:threshed];
    
    // if there is an image in scrollView it will remove it
    [self.imageView removeFromSuperview];
    
    if (threshed == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Test image thresholding failed! Please try taking the picture again" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        self.scrollView.backgroundColor = [UIColor whiteColor]; // hides scrollView
    }
    else {
        self.imageView = imageView;
        [self.scrollView addSubview:imageView];
        self.scrollView.backgroundColor = [UIColor blackColor];
        self.scrollView.contentSize = self.imageView.bounds.size;
        self.scrollView.maximumZoomScale = 4.0;
        self.scrollView.minimumZoomScale = 0.5;
        self.scrollView.contentOffset = CGPointMake(-(self.scrollView.bounds.size.width-self.imageView.bounds.size.width)/2, -(self.scrollView.bounds.size.height-self.imageView.bounds.size.height)/2);
        // save threshed image to global copy for detecting contours
    }
    
    
}

-(void)sendData{
    int studyID = studyNumber;
    int trialID = trialNumber;
    
    server = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@", IPAddress]];
    
    
    // get rid of trailing space in results string
    int i = 0;
    while(results[i] != '\0') {
        if(results[i+1] == '\0')
            results[i] = '\0';
        i++;
    }
    
    NSString *temp = [NSString stringWithCString:results encoding:NSASCIIStringEncoding];
    
    fileContents = temp;
    
    NSString *escapedFileContents = [fileContents stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]];
    NSLog(@"%@", escapedFileContents);
    
    NSString *content;
    while (!content){
        NSString *stringText = [NSString stringWithFormat:@"mapInput.php?studyID=%d&trialID=%d&map=%@", studyID, trialID, escapedFileContents];
        content = [NSString stringWithContentsOfURL:[NSURL URLWithString: stringText relativeToURL:server] encoding:NSUTF8StringEncoding error:nil];
    }
    NSLog(@"%@", content);
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    studyNum = ([self.studyNumber.text length] == 0) ? 0 : 1;
    studyNumber = [self.studyNumber.text integerValue];
    trialNumber = [self.trialNumber.text integerValue];
    IPAddress = self.IPAddress.text;
    hsvStart = self.hsvStart.text;
    hsvEnd = self.hsvEnd.text;
    if([IPAddress length] == 0) IPAddress = nil;
    if([hsvStart length] == 0) hsvStart = nil;
    if([hsvEnd length] == 0) hsvEnd = nil;
    NSLog(@"hsv Start %@\n", hsvStart);
    NSLog(@"hsv End %@\n", hsvEnd);
    [self.hsvStart resignFirstResponder];
    [self.hsvEnd resignFirstResponder];
    [self.IPAddress resignFirstResponder];
    [self.studyNumber resignFirstResponder];
    [self.trialNumber resignFirstResponder];
    return YES;
}


- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
    return YES;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - scroll view delegate

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return self.imageView;
}



- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    savedImage = info[UIImagePickerControllerOriginalImage];
    
    userImage = info[UIImagePickerControllerOriginalImage];
    self.imageView2.image = userImage;
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

- (IBAction)incrementStudyNum:(UIButton *)sender {
    studyNumber++;
    studyNum = 1; // flip bool checking if studyNumber text field is empty
    self.studyNumber.text = [NSString stringWithFormat:@"%d", studyNumber];
    
}

- (IBAction)incrementTrialNum:(UIButton *)sender {
    trialNumber++;
    self.trialNumber.text = [NSString stringWithFormat:@"%d", trialNumber];
}

- (IBAction)takePhoto:(UIButton *)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = NO;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:picker animated:YES completion:NULL];
}


- (IBAction)process:(UIButton *)sender {
    
    [self processMap];
    
}


-(void)processMap{
    int t = 0, c = 0, w = 0;
    
    t = [self threshy];
    if(t) {
        c = [self contoury];
    }
    if(c) {
        w = [self warpy];
    }
    
    
    if(w){
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Does this look like your map?" message:@"If so, click analyze. If not, retake the image and reprocess" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
    }
}

-(int)threshy{
   
    
    if (userImage == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"No image to threshold! \nTake a photo of the entire board" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        return 0;
    }
    
    /* thresholds image
     ** colorCases: 0 = green
     **             1 = red
     **             2 = wood
     **             3 = blue
     **             4 = dark green (corner markers)
     */
    
    
    UIImage* threshed = nil;
    threshed = [CVWrapper thresh:userImage colorCase: 4 hsvValues:hsvTests];
    
    //** following code shows thresholded image in scrollView
    UIImageView *imageView = [[UIImageView alloc] initWithImage:threshed];
    
    // if there is an image in scrollView it will remove it
    [self.imageView removeFromSuperview];
    
    if (threshed == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Image thresholding failed! Please try taking the picture again" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        self.scrollView.backgroundColor = [UIColor whiteColor]; // hides scrollView
        return 0;
    }
    else {
        self.imageView = imageView;
        [self.scrollView addSubview:imageView];
        self.scrollView.backgroundColor = [UIColor blackColor];
        self.scrollView.contentSize = self.imageView.bounds.size;
        self.scrollView.maximumZoomScale = 4.0;
        self.scrollView.minimumZoomScale = 0.5;
        self.scrollView.contentOffset = CGPointMake(-(self.scrollView.bounds.size.width-self.imageView.bounds.size.width)/2, -(self.scrollView.bounds.size.height-self.imageView.bounds.size.height)/2);
        // save threshed image to global copy for detecting contours
        threshedGlobal = threshed;
        return 1;
    }
    
    //** end of code showing thresholded image in scrollView5000

}
-(int)contoury{
    if(threshedGlobal == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Image was not thresholded. Threshold your image!" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        self.scrollView.backgroundColor = [UIColor whiteColor]; // hides scrollView
        return 0;
    }
    
    int width = [CVWrapper detectContours:threshedGlobal corners:cornersGlobal];
    
    if(width != 0) {
        widthGlobal = abs(width);
    }
    else widthGlobal = 1;
    
    return 1;

}
-(int)warpy{
    /*
     * get threshed image
     * find triangle contours on threshed image
     * get Point2f of those triangle contours
     * plug those points into warper
     */
    
    
    
    int height = (widthGlobal * 23) / 25;
    if (userImage == nil || threshedGlobal == nil || widthGlobal == 0) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Can not warp! \nMake sure you threshold and contour first!" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        return 0;
    }
    
    // make blank image of size widthXheight
    UIImage *dst = nil;
    CGSize targetSize = CGSizeMake(widthGlobal, height);
    UIGraphicsBeginImageContext(targetSize);
    
    CGRect thumbnailRect = CGRectMake(0, 0, 0, 0);
    thumbnailRect.origin = CGPointMake(0.0,0.0);
    thumbnailRect.size.width  = targetSize.width;
    thumbnailRect.size.height = targetSize.height;
    
    [userImage drawInRect:thumbnailRect];
    
    
    dst = UIGraphicsGetImageFromCurrentImageContext();
    
    
    UIGraphicsEndImageContext();
    // finished making image
    
    
    // make a UIImage which will be perspectively warped from stitchedImage
    // use stitchedImageGlobal because it is the global equivalent to stitchedImage
    UIImage* destination = [CVWrapper warp:userImage destination_image:dst];
    
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:destination];
    
    
    
    //** following code shows warped image in scrollView
    
    // if there is an image in scrollView it will remove it
    [self.imageView removeFromSuperview];
    
    
    if (destination == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Image warping failed! \nPlease take your picture again" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        self.scrollView.backgroundColor = [UIColor whiteColor]; // hides scrollView
        return 0;
    }
    else {
        warpedGlobal = destination;
        self.imageView = imageView;
        [self.scrollView addSubview:imageView];
        self.scrollView.backgroundColor = [UIColor blackColor];
        self.scrollView.contentSize = self.imageView.bounds.size;
        self.scrollView.maximumZoomScale = 4.0;
        self.scrollView.minimumZoomScale = 0.5;
        self.scrollView.contentOffset = CGPointMake(-(self.scrollView.bounds.size.width-self.imageView.bounds.size.width)/2, -(self.scrollView.bounds.size.height-self.imageView.bounds.size.height)/2);
        return 1;
        
    }
    
    //** end of code showing warped image in scrollView

}




// run analysis to find marker pieces on map
- (IBAction)analyze:(UIButton *)sender {
    
    if(IPAddress == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Enter the server IP address" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    if(studyNum == 0) { // checks if bool studyNum is false (means studyNumber text field is empty)
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Enter your study number" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    if(studyNumber < -1) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Enter your trial number" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    // for testing
    UIImage* testImg = [UIImage imageNamed:@"single25.JPG"];
    
    int worked;
    if(warpedGlobal == nil) {
        worked = [CVWrapper analysis:testImg studyNumber: studyNumber trialNumber:trialNumber results: results hsvValues:hsvTests];
    }
    else {
        worked = [CVWrapper analysis:warpedGlobal studyNumber: studyNumber trialNumber:trialNumber results: results hsvValues:hsvTests];
    }
    
    if(worked) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Success!" message:@"We found your pieces!" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        [self sendData];
    }
    else {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Oops!" message:@"We couldn't find your pieces!" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
    }
}



// reset
- (IBAction)ClearUI:(UIButton *)sender {
    userImage = nil;
    threshedGlobal = nil;
    warpedGlobal = nil;
    widthGlobal = 0;
    self.imageView.image  = nil;
    self.imageView2.image = nil;
    self.scrollView.backgroundColor = [UIColor whiteColor]; // hides scrollView

}
@end

