//
//  CVViewController.m
//  CVOpenTemplate
//
//  Created by Washe on 02/01/2013.
//  Copyright (c) 2013 foundry. All rights reserved.

//  EcoCollage 2015
//  Ryan Fogarty
//  Salvador Ariza

#import "CVViewController.h"
#import "CVWrapper.h"
#import <math.h>
#import <stdlib.h>

@interface CVViewController ()


@end

@implementation CVViewController


int cornersGlobal[8];
int studyNumber;
int trialNumber;
int widthGlobal = 0;

UIImage *userImage = nil;
UIImage *savedImage;
UIImage *threshedGlobal;
UIImage *warpedGlobal;

- (void)viewDidAppear:(BOOL)animated    
{
    [super viewDidAppear:animated];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    studyNumber = [self.studyNumber.text integerValue];
    trialNumber = [self.trialNumber.text integerValue];
    printf("Study Number is: %d\n", studyNumber);
    printf("Trial Number is: %d\n", trialNumber);
    [self.studyNumber resignFirstResponder];
    [self.trialNumber resignFirstResponder];
    return YES;
}


- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
    return YES;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - scroll view delegate

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return self.imageView;
}



- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    savedImage = info[UIImagePickerControllerOriginalImage];
    
    userImage = info[UIImagePickerControllerOriginalImage];
    self.imageView2.image = userImage;
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}



- (IBAction)takePhoto:(UIButton *)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = NO;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:picker animated:YES completion:NULL];
}

    

- (IBAction)threshold:(UIButton *)sender {

    if (userImage == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"No image to threshold! \nTake a photo of the entire board" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    /* thresholds image
    ** colorCases: 0 = green
    **             1 = red
    **             2 = wood
    **             3 = blue
    **             4 = black
    **             6 = dark green (corner markers)
    */

    
    UIImage* threshed = nil;
    threshed = [CVWrapper thresh:userImage colorCase: 6];

    //** following code shows thresholded image in scrollView
    UIImageView *imageView = [[UIImageView alloc] initWithImage:threshed];
    
    // if there is an image in scrollView it will remove it
    [self.imageView removeFromSuperview];
    
    if (threshed == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Image thresholding failed! Please try taking the picture again" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        self.scrollView.backgroundColor = [UIColor whiteColor]; // hides scrollView

    }
    else {
        self.imageView = imageView;
        [self.scrollView addSubview:imageView];
        self.scrollView.backgroundColor = [UIColor blackColor];
        self.scrollView.contentSize = self.imageView.bounds.size;
        self.scrollView.maximumZoomScale = 4.0;
        self.scrollView.minimumZoomScale = 0.5;
        self.scrollView.contentOffset = CGPointMake(-(self.scrollView.bounds.size.width-self.imageView.bounds.size.width)/2, -(self.scrollView.bounds.size.height-self.imageView.bounds.size.height)/2);
        // save threshed image to global copy for detecting contours
        threshedGlobal = threshed;
    }
    
    //** end of code showing thresholded image in scrollView
}

- (IBAction)detectContours:(UIButton *)sender {
    if(threshedGlobal == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Image was not thresholded. Threshold your image!" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        self.scrollView.backgroundColor = [UIColor whiteColor]; // hides scrollView
        return;
    }
    
    int width = [CVWrapper detectContours:threshedGlobal corners:cornersGlobal];
    
    
    NSString *text = [NSString stringWithFormat:@"Corner 0: x: %d y: %d\nCorner 1: x: %d y: %d\nCorner 2: x: %d y: %d\nCorner 3: x: %d y: %d\n", cornersGlobal[0], cornersGlobal[1], cornersGlobal[2], cornersGlobal[3], cornersGlobal[4], cornersGlobal[5], cornersGlobal[6], cornersGlobal[7]];
    
    [self cornersInfo].text = text;
    if(width != 0) {
        widthGlobal = abs(width);
    }
    else widthGlobal = 1;

}

- (IBAction)warp:(UIButton *)sender {
    
    /*
     * get threshed image
     * find triangle contours on threshed image
     * get Point2f of those triangle contours
     * plug those points into warper
     */
    
    
    
    int height = (widthGlobal * 23) / 25;
    if (userImage == nil || threshedGlobal == nil || widthGlobal == 0) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Can not warp! \nMake sure you threshold and contour first!" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    // make blank image of size widthXheight
    UIImage *dst = nil;
    CGSize targetSize = CGSizeMake(widthGlobal, height);
    UIGraphicsBeginImageContext(targetSize);
    
    CGRect thumbnailRect = CGRectMake(0, 0, 0, 0);
    thumbnailRect.origin = CGPointMake(0.0,0.0);
    thumbnailRect.size.width  = targetSize.width;
    thumbnailRect.size.height = targetSize.height;
    
    [userImage drawInRect:thumbnailRect];
    
    
    dst = UIGraphicsGetImageFromCurrentImageContext();
    
    
    UIGraphicsEndImageContext();
    // finished making image
    
    
    // make a UIImage which will be perspectively warped from stitchedImage
    // use stitchedImageGlobal because it is the global equivalent to stitchedImage
    UIImage* destination = [CVWrapper warp:userImage destination_image:dst];
    
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:destination];
    
    
    
    //** following code shows warped image in scrollView
    
    // if there is an image in scrollView it will remove it
    [self.imageView removeFromSuperview];
    
    
    if (destination == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Image warping failed! \nPlease take your picture again" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        self.scrollView.backgroundColor = [UIColor whiteColor]; // hides scrollView
    }
    else {
        warpedGlobal = destination;
        self.imageView = imageView;
        [self.scrollView addSubview:imageView];
        self.scrollView.backgroundColor = [UIColor blackColor];
        self.scrollView.contentSize = self.imageView.bounds.size;
        self.scrollView.maximumZoomScale = 4.0;
        self.scrollView.minimumZoomScale = 0.5;
        self.scrollView.contentOffset = CGPointMake(-(self.scrollView.bounds.size.width-self.imageView.bounds.size.width)/2, -(self.scrollView.bounds.size.height-self.imageView.bounds.size.height)/2);
        
    }
    
    //** end of code showing warped image in scrollView
}



// run analysis of the old code on the warped board
- (IBAction)analyze:(UIButton *)sender {
    /*
    if(studyNumber <= 0) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Enter your study number" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        return;
    }
    
    if(trialNumber <= 0) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Enter your trial number" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        return;
    }
    */
    // for testing
    UIImage* testImg = [UIImage imageNamed:@"single16.JPG"];
    
    int worked;
    if(warpedGlobal == nil) {
        worked = [CVWrapper analysis:testImg studyNumber: studyNumber trialNumber:trialNumber];
    }
    else {
        worked = [CVWrapper analysis:warpedGlobal studyNumber: studyNumber trialNumber:trialNumber];
    }
    
    if(worked) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Success!" message:@"We found your pieces!" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
    }
    else {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Oops!" message:@"We couldn't find your pieces!" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
    }
}

- (IBAction)saveImage:(UIButton *)sender {
    if(warpedGlobal != nil) {
        UIImageWriteToSavedPhotosAlbum(warpedGlobal, nil, nil, nil);
    }
}

- (IBAction)studyNumber:(UITextField *)sender {
    
}

// reset
- (IBAction)ClearUI:(UIButton *)sender {
    userImage = nil;
    threshedGlobal = nil;
    warpedGlobal = nil;
    widthGlobal = 0;
    studyNumber = 0;
    trialNumber = 0;
    self.studyNumber.text = nil;
    self.trialNumber.text = nil;
    self.imageView.image  = nil;
    self.imageView2.image = nil;
    self.scrollView.backgroundColor = [UIColor whiteColor]; // hides scrollView

}
@end

