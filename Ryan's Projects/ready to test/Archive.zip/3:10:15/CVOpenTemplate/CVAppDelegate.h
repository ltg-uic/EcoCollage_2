//
//  CVAppDelegate.h
//  CVOpenTemplate
//
//  Created by Washe on 02/01/2013.
//  Copyright (c) 2013 foundry. All rights reserved.
//


//  EcoCollage 2015
//  Ryan Fogarty
//  Salvador Ariza

#import <UIKit/UIKit.h>

@interface CVAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
