//
//  CVViewController.m
//  CVOpenTemplate
//
//  Created by Washe on 02/01/2013.
//  Copyright (c) 2013 foundry. All rights reserved.

//  EcoCollage 2015
//  Ryan Fogarty
//

#import "CVViewController.h"
#import "CVWrapper.h"
#import <math.h>


@interface CVViewController ()

@end

@implementation CVViewController


int colorCase = 0;
int cornersGlobal[8];


// pertains to which imageView the currently a photo should display in next
int image_location = 1;
int widthGlobal = 0;

UIImage *userImage;
UIImage *userImage2;
UIImage *savedImage;
UIImage *stitchedImageGlobal;
UIImage *threshedGlobal;
UIImage *warpedGlobal;

- (void)viewDidAppear:(BOOL)animated    
{
    [super viewDidAppear:animated];
    //[self stitch];
}


- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
    return YES;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - scroll view delegate

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return self.imageView;
}



- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    savedImage = info[UIImagePickerControllerOriginalImage];
    
    // display photo in the correct UIImageView
    switch(image_location){
        case 1:
            userImage = info[UIImagePickerControllerOriginalImage];
            self.imageView2.image = userImage;
            image_location = 2;
            break;
        case 2:
            userImage2 = info[UIImagePickerControllerOriginalImage];
            self.imageView3.image = userImage2;
            image_location = 1;
            break;
        default:
            break;
            
    }
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}



- (IBAction)stitchImages:(UIButton *)sender {
    [self.spinner startAnimating];
    [self.textView setHidden:NO];
 
    if (userImage == nil || userImage2 == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Needs two images to stitch! \nMake sure you took two pictures!" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        [self.spinner stopAnimating];
        [self.textView setHidden:YES];
        return;
        
    }
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        
        
        /*
         * being process of reducing size of images from 960x720 to 480x360 (1/2), or 640x480 (2/3)
         */
        
        UIImage *reducedImage = nil;
        CGSize targetSize = CGSizeMake(480, 360);
        UIGraphicsBeginImageContext(targetSize);
        
        CGRect thumbnailRect = CGRectMake(0, 0, 0, 0);
        thumbnailRect.origin = CGPointMake(0.0,0.0);
        thumbnailRect.size.width  = targetSize.width;
        thumbnailRect.size.height = targetSize.height;
        
        [userImage drawInRect:thumbnailRect];
        
        reducedImage = UIGraphicsGetImageFromCurrentImageContext();
        
        UIGraphicsEndImageContext();


        UIImage *reducedImage2 = nil;
        CGSize targetSize2 = CGSizeMake(480, 360);
        UIGraphicsBeginImageContext(targetSize2);
        
        CGRect thumbnailRect2 = CGRectMake(0, 0, 0, 0);
        thumbnailRect2.origin = CGPointMake(0.0,0.0);
        thumbnailRect2.size.width  = targetSize2.width;
        thumbnailRect2.size.height = targetSize2.height;
        
        [userImage2 drawInRect:thumbnailRect2];
        
        reducedImage2 = UIGraphicsGetImageFromCurrentImageContext();
        
        UIGraphicsEndImageContext();
        
         /*
         * end process of reducing image sizes
         */
        
        printf("%f %f\n", userImage.size.width, userImage.size.height);
        
        NSArray* imageArray = [NSArray arrayWithObjects:userImage, userImage2, nil];
        
        UIImage* stitchedImage = nil;
        
        
        // will return nil if stitching fails
        stitchedImage = [CVWrapper processWithArray:imageArray];
        

        
        // save stitchedImage
        //UIImageWriteToSavedPhotosAlbum(stitchedImage, nil, nil, nil);
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            NSLog (@"stitchedImage %@",stitchedImage);
            UIImageView *imageView = [[UIImageView alloc] initWithImage:stitchedImage];
            
            
            // if there is an image in scrollView it will remove it
            [self.imageView removeFromSuperview];
            

            if (stitchedImage == nil) {
                UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Image stitching failed! \nPlease try again" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
                [alert show];
                self.scrollView.backgroundColor = [UIColor whiteColor]; // hides scrollView 
            }
            else {
            self.imageView = imageView;
            [self.scrollView addSubview:imageView];
            self.scrollView.backgroundColor = [UIColor blackColor];
            self.scrollView.contentSize = self.imageView.bounds.size;
            self.scrollView.maximumZoomScale = 4.0;
            self.scrollView.minimumZoomScale = 0.5;
            self.scrollView.contentOffset = CGPointMake(-(self.scrollView.bounds.size.width-self.imageView.bounds.size.width)/2, -(self.scrollView.bounds.size.height-self.imageView.bounds.size.height)/2);
            // save stitched image to global copy for warping
            stitchedImageGlobal = stitchedImage;
            }
            [self.spinner stopAnimating];
            [self.textView setHidden:YES];
        });
    });
    
}


- (IBAction)takePhoto:(UIButton *)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = NO;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:picker animated:YES completion:NULL];
}

    
- (IBAction)warp:(UIButton *)sender {
    
    /*
     * get threshed image
     * find triangle contours on threshed image
     * get Point2f of those triangle contours
     * plug those points into warper
     */
    

    
    int height = (widthGlobal * 23) / 25;
    
    if (stitchedImageGlobal == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"No stitched image to warp! \nStitch your image!" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        return;
    }
    // make blank image of size widthXheight
    UIImage *dst = nil;
    CGSize targetSize = CGSizeMake(widthGlobal, height);
    UIGraphicsBeginImageContext(targetSize);
    
    CGRect thumbnailRect = CGRectMake(0, 0, 0, 0);
    thumbnailRect.origin = CGPointMake(0.0,0.0);
    thumbnailRect.size.width  = targetSize.width;
    thumbnailRect.size.height = targetSize.height;
    
    [userImage drawInRect:thumbnailRect];
    
    
    dst = UIGraphicsGetImageFromCurrentImageContext();
    
    
    UIGraphicsEndImageContext();
    // finished making image
    

    
    // make a UIImage which will be perspectively warped from stitchedImage
    // use stitchedImageGlobal because it is the global equivalent to stitchedImage
    UIImage* destination = [CVWrapper warp:stitchedImageGlobal destination_image:dst];

    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:destination];
    
    
    
    //** following code shows warped image in scrollView
    
    // if there is an image in scrollView it will remove it
    [self.imageView removeFromSuperview];
    
    
    if (destination == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Image warping failed! \nPlease try again" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        self.scrollView.backgroundColor = [UIColor whiteColor]; // hides scrollView
    }
    else {
        warpedGlobal = destination;
        self.imageView = imageView;
        [self.scrollView addSubview:imageView];
        self.scrollView.backgroundColor = [UIColor blackColor];
        self.scrollView.contentSize = self.imageView.bounds.size;
        self.scrollView.maximumZoomScale = 4.0;
        self.scrollView.minimumZoomScale = 0.5;
        self.scrollView.contentOffset = CGPointMake(-(self.scrollView.bounds.size.width-self.imageView.bounds.size.width)/2, -(self.scrollView.bounds.size.height-self.imageView.bounds.size.height)/2);

    }
    
    //** end of code showing warped image in scrollView
    

}

- (IBAction)threshold:(UIButton *)sender {
    
    if (stitchedImageGlobal == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"No stitched image to threshold! \nStitch your image!" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        return;
    }
    /* thresholds image
    ** colorCases: 0 = green
    **             1 = red
    **             2 = wood
    **             3 = blue
    **             4 = black
    */
    

    
    UIImage* threshed = nil;
    threshed = [CVWrapper thresh:stitchedImageGlobal colorCase: 0];
    
    //** following code shows thresholded image in scrollView
    UIImageView *imageView = [[UIImageView alloc] initWithImage:threshed];
    
    
    // if there is an image in scrollView it will remove it
    [self.imageView removeFromSuperview];
    
    
    if (threshed == nil) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Image thresholding failed! Please try again" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
        self.scrollView.backgroundColor = [UIColor whiteColor]; // hides scrollView

    }
    else {
        self.imageView = imageView;
        [self.scrollView addSubview:imageView];
        self.scrollView.backgroundColor = [UIColor blackColor];
        self.scrollView.contentSize = self.imageView.bounds.size;
        self.scrollView.maximumZoomScale = 4.0;
        self.scrollView.minimumZoomScale = 0.5;
        self.scrollView.contentOffset = CGPointMake(-(self.scrollView.bounds.size.width-self.imageView.bounds.size.width)/2, -(self.scrollView.bounds.size.height-self.imageView.bounds.size.height)/2);
        // save threshed image to global copy for detecting contours
        threshedGlobal = threshed;
    }
    
    //** end of code showing thresholded image in scrollView
}

- (IBAction)detectContours:(UIButton *)sender {

    
    int width = [CVWrapper detectContours:threshedGlobal corners:cornersGlobal];
    
    
    NSString *text = [NSString stringWithFormat:@"Corner 0: x: %d y: %d\nCorner 1: x: %d y: %d\nCorner 2: x: %d y: %d\nCorner 3: x: %d y: %d\n", cornersGlobal[0], cornersGlobal[1], cornersGlobal[2], cornersGlobal[3], cornersGlobal[4], cornersGlobal[5], cornersGlobal[6], cornersGlobal[7]];
    
    [self cornersInfo].text = text;
    if(width != 0) {
        widthGlobal = abs(width);
    }
    else widthGlobal = 1;

}


// run analysis of the old code on the warped board
- (IBAction)analyze:(UIButton *)sender {
    
    // for testing
    UIImage* testImg = [UIImage imageNamed:@"board15.JPG"];
    
    int worked;
    if(warpedGlobal == nil) {
        worked = [CVWrapper analysis:testImg];
    }
    else {
        worked = [CVWrapper analysis:warpedGlobal];
    }
    
    if(worked) {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Success!" message:@"We found your pieces!" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
    }
    else {
        UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Oops!" message:@"We couldn't find your pieces!" delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:nil];
        [alert show];
    }
}

- (IBAction)saveImage:(UIButton *)sender {
    if(warpedGlobal != nil) {
        UIImageWriteToSavedPhotosAlbum(warpedGlobal, nil, nil, nil);
    }
}



@end

