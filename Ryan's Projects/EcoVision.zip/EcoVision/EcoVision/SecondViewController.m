//
//  SecondViewController.m
//  EcoVision
//
//  Created by LTG-Guest on 4/8/15.
//  Copyright (c) 2015 EcoCollage. All rights reserved.
//

#import "SecondViewController.h"
#import "CVWrapper.h"
#import <math.h>
#import <stdlib.h>

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)printHSV_Values:(UIButton *)sender {
    int* hsvValues = malloc(sizeof(int) * 30);
    [CVWrapper getHSV_Values: hsvValues];
    
    int i;
    for(i = 0; i < 30; i++) {
        printf("%d\n", hsvValues[i]);
    }
    
    free(hsvValues);
}
- (IBAction)labelSlider:(NMRangeSlider *)sender {
}
- (IBAction)labelSlider:(NMRangeSlider *)sender forEvent:(UIEvent *)event {
}
@end
