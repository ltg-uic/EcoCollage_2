//
//  NMDemoTVC.m
//  NMRangeSlider
//
//  Created by Murray Hughes on 04/08/2012
//  Copyright 2011 Null Monkey Pty Ltd. All rights reserved.
//


#import "NMDemoTVC.h"
#import "CVWrapper.h"

@interface NMDemoTVC ()

@end

@implementation NMDemoTVC




#pragma mark -
#pragma mark - View LifeCycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self configureLabelSliders];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (void) viewDidAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self updateSliderLabels];
    [self updateSliderLabels2];
    [self updateSliderLabels3];
    
    if([self.view respondsToSelector:@selector(setTintColor:)])
    {
        self.view.tintColor = [UIColor orangeColor];
    }
    
}


- (void) configureLabelSliders
{
    int* hsvValues = malloc(sizeof(int) * 30);
    int segmentIndex = [CVWrapper getSegmentIndex];
    [CVWrapper getHSV_Values:hsvValues];
    
    self.labelSlider.minimumValue = 0;
    self.labelSlider.maximumValue = 255;
    self.labelSlider.lowerValue = hsvValues[0 + segmentIndex*6];
    self.labelSlider.upperValue = hsvValues[1 + segmentIndex*6];
    self.labelSlider.minimumRange = 10;
    
    
    self.labelSlider2.minimumValue = 0;
    self.labelSlider2.maximumValue = 255;
    self.labelSlider2.lowerValue = hsvValues[2 + segmentIndex*6];
    self.labelSlider2.upperValue = hsvValues[3 + segmentIndex*6];
    self.labelSlider2.minimumRange = 10;
    
    
    self.labelSlider3.minimumValue = 0;
    self.labelSlider3.maximumValue = 255;
    self.labelSlider3.lowerValue = hsvValues[4 + segmentIndex*6];
    self.labelSlider3.upperValue = hsvValues[5 + segmentIndex*6];
    self.labelSlider3.minimumRange = 10;
    
    free(hsvValues);
}

- (void) updateSliderLabels
{
    // You get get the center point of the slider handles and use this to arrange other subviews

    int* hsvValues = malloc(sizeof(int) * 30);
    int segmentIndex = [CVWrapper getSegmentIndex];
    [CVWrapper getHSV_Values:hsvValues];
    
    hsvValues[0 + segmentIndex*6] = self.labelSlider.lowerValue;
    hsvValues[1 + segmentIndex*6] = self.labelSlider.upperValue;
    [CVWrapper setHSV_Values:hsvValues];
    
    CGPoint lowerCenter;
    lowerCenter.x = (self.labelSlider.lowerCenter.x + self.labelSlider.frame.origin.x);
    lowerCenter.y = (self.labelSlider.center.y - 30.0f);
    self.lowerLabel.center = lowerCenter;
    self.lowerLabel.text = [NSString stringWithFormat:@"%d", (int)self.labelSlider.lowerValue];
    
    CGPoint upperCenter;
    upperCenter.x = (self.labelSlider.upperCenter.x + self.labelSlider.frame.origin.x);
    upperCenter.y = (self.labelSlider.center.y - 30.0f);
    self.upperLabel.center = upperCenter;
    self.upperLabel.text = [NSString stringWithFormat:@"%d", (int)self.labelSlider.upperValue];

    free(hsvValues);
}

- (void) updateSliderLabels2
{
    // You get get the center point of the slider handles and use this to arrange other subviews
    
    int* hsvValues = malloc(sizeof(int) * 30);
    int segmentIndex = [CVWrapper getSegmentIndex];
    [CVWrapper getHSV_Values:hsvValues];
    
    hsvValues[2 + segmentIndex*6] = self.labelSlider.lowerValue;
    hsvValues[3 + segmentIndex*6] = self.labelSlider.upperValue;
    [CVWrapper setHSV_Values:hsvValues];
    
    CGPoint lowerCenter;
    lowerCenter.x = (self.labelSlider2.lowerCenter.x + self.labelSlider2.frame.origin.x);
    lowerCenter.y = (self.labelSlider2.center.y - 30.0f);
    self.lowerLabel2.center = lowerCenter;
    self.lowerLabel2.text = [NSString stringWithFormat:@"%d", (int)self.labelSlider2.lowerValue];
    
    CGPoint upperCenter;
    upperCenter.x = (self.labelSlider2.upperCenter.x + self.labelSlider2.frame.origin.x);
    upperCenter.y = (self.labelSlider2.center.y - 30.0f);
    self.upperLabel2.center = upperCenter;
    self.upperLabel2.text = [NSString stringWithFormat:@"%d", (int)self.labelSlider2.upperValue];
    
    free(hsvValues);
}

- (void) updateSliderLabels3
{
    // You get get the center point of the slider handles and use this to arrange other subviews
    
    int* hsvValues = malloc(sizeof(int) * 30);
    int segmentIndex = [CVWrapper getSegmentIndex];
    [CVWrapper getHSV_Values:hsvValues];
    
    hsvValues[4 + segmentIndex*6] = self.labelSlider.lowerValue;
    hsvValues[5 + segmentIndex*6] = self.labelSlider.upperValue;
    [CVWrapper setHSV_Values:hsvValues];
    
    CGPoint lowerCenter;
    lowerCenter.x = (self.labelSlider3.lowerCenter.x + self.labelSlider3.frame.origin.x);
    lowerCenter.y = (self.labelSlider3.center.y - 30.0f);
    self.lowerLabel3.center = lowerCenter;
    self.lowerLabel3.text = [NSString stringWithFormat:@"%d", (int)self.labelSlider3.lowerValue];
    
    CGPoint upperCenter;
    upperCenter.x = (self.labelSlider3.upperCenter.x + self.labelSlider3.frame.origin.x);
    upperCenter.y = (self.labelSlider3.center.y - 30.0f);
    self.upperLabel3.center = upperCenter;
    self.upperLabel3.text = [NSString stringWithFormat:@"%d", (int)self.labelSlider3.upperValue];
}


// Handle control value changed events just like a normal slider
- (IBAction)labelSliderChanged:(NMRangeSlider*)sender
{
    [self updateSliderLabels];
}

- (IBAction)labelSliderChanged2:(NMRangeSlider*)sender
{
    [self updateSliderLabels2];
}

- (IBAction)labelSliderChanged3:(NMRangeSlider*)sender
{
    [self updateSliderLabels3];
}

+ (void) segmentControlChanged {
    printf("Segment Control Changed %d\n", [CVWrapper getSegmentIndex]);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([tableView cellForRowAtIndexPath:indexPath].tag==1)
    {
        [tableView deselectRowAtIndexPath:indexPath animated:NO];
    }
}


@end
