//
//  main.m
//  NMRangeSlider
//
//  Created by Murray Hughes on 4/08/12.
//  Copyright (c) 2012 Null Monkey. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NMAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([NMAppDelegate class]));
    }
}
