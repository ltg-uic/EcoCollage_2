//
//  ViewController.m
//  openCV
//
//  Created by LTG-Guest on 2/12/15.
//  Copyright (c) 2015 LTG-Guest. All rights reserved.
//


#import "ViewController.h"
#import <stdio.h>

@interface ViewController ()

@end

@implementation ViewController

//int last_pressed = 0;

// pertains to which imageView the currently a photo should display in next
int image_location = 1;

// only save when "take photo" was clicked, not when "select photo" was clicked
bool should_save = 0;

UIImage *chosenImage;
UIImage *chosenImage2;
UIImage *chosenImage3;
UIImage *chosenImage4;
UIImage *savedImage;
UIImage *stitchedImage1;



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        
        UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                              message:@"Device has no camera"
                                                             delegate:nil
                                                    cancelButtonTitle:@"OK"
                                                    otherButtonTitles: nil];
        
        [myAlertView show];
    }
    
    
    
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// DISABLED EDITING
// IF WE WANT IMAGE EDITING TO BE ALLOWED:
// WE MUST CHANGE             chosenImage = info[UIImagePickerControllerOriginalImage];
// TO             chosenImage = info[UIImagePickerControllerEditedImage];
// IN THE METHOD didFinishPickingMediaWithInfo
// AND CHANGE THE    picker.allowsEditing = NO;
// TO     picker.allowsEditing = YES;
// IN takePhoto AND selectPhoto methods

// ALLOWING EDITING AUTOMATICALLY CROPS THE IMAGE AND SAVES IT AS THE CROPPED IMAGE
// DISABLED EDITING SO THAT ORIGINAL PICTURE IS SAVED AND DISPLAYED

- (IBAction)takePhoto:(UIButton *)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = NO;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    //last_pressed = 1;
    should_save = 1;
    [self presentViewController:picker animated:YES completion:NULL];
}

- (IBAction)selectPhoto:(UIButton *)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = NO;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    //last_pressed = 1;
    should_save = 0;
    [self presentViewController:picker animated:YES completion:NULL];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    savedImage = info[UIImagePickerControllerOriginalImage];
    
    // display photo in the correct UIImageView
    switch(image_location){
        case 1:
            chosenImage = info[UIImagePickerControllerOriginalImage];
            self.imageView1.image = chosenImage;
            image_location++;
            break;
        case 2:
            chosenImage2 = info[UIImagePickerControllerOriginalImage];
            self.imageView2.image = chosenImage2;
            image_location++;
            break;
        case 3:
            chosenImage3 = info[UIImagePickerControllerOriginalImage];
            self.imageView3.image = chosenImage3;
            image_location++;
            break;
        case 4:
            chosenImage4 = info[UIImagePickerControllerOriginalImage];
            self.imageView4.image = chosenImage4;
            image_location = 1;
            break;
    }
    
    // if user clicked "take photo", it should save photo
    // if user clicked "select photo", it should not save photo
    if (should_save){
        UIImageWriteToSavedPhotosAlbum(chosenImage, nil, nil, nil);
    }
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

- (IBAction)stitcher:(UIButton *)sender {
        printf("Hello Stitcher\n");
}
@end
