//
//  ViewController.h
//  openCV
//
//  Created by LTG-Guest on 2/12/15.
//  Copyright (c) 2015 LTG-Guest. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>


// 4 image views linked in the following way
/*
 1 | 2
 -----
 3 | 4
 */

@property (strong, nonatomic) IBOutlet UIImageView *imageView1;
@property (strong, nonatomic) IBOutlet UIImageView *imageView2;
@property (strong, nonatomic) IBOutlet UIImageView *imageView3;
@property (strong, nonatomic) IBOutlet UIImageView *imageView4;
- (IBAction)takePhoto:(UIButton *)sender;
- (IBAction)selectPhoto:(UIButton *)sender;
- (IBAction)Stitch:(UIButton *)sender;


@end

