//
//  main.m
//  openCV
//
//  Created by LTG-Guest on 2/12/15.
//  Copyright (c) 2015 LTG-Guest. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import <stdio.h>

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
