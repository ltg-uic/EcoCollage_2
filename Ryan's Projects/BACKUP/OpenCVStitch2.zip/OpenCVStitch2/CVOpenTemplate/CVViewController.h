//
//  CVViewController.h
//  CVOpenTemplate
//
//  Created by Washe on 02/01/2013.
//  Copyright (c) 2013 foundry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CVViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView* spinner;
@property (nonatomic, weak) IBOutlet UIImageView* imageView;
@property (strong, nonatomic) IBOutlet UIImageView *imageView2;
@property (strong, nonatomic) IBOutlet UIImageView *imageView3;
- (IBAction)takePhoto:(id)sender;
- (IBAction)stitchImages:(UIButton *)sender;
@property (nonatomic, weak) IBOutlet UIScrollView* scrollView;
@end
