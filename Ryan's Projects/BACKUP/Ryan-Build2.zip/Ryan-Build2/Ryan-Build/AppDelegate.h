//
//  AppDelegate.h
//  Ryan-Build
//
//  Created by LTG-Guest on 2/13/15.
//  Copyright (c) 2015 EcoCollage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

