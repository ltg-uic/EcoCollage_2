//
//  APPViewController.h
//  Camera
//
//  Created by LTG_Ugrad on 2/10/15.
//  Copyright (c) 2015 LTG_Ugrad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface APPViewController : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>



// 4 image views linked in the following way
/*
 1 | 2
 -----
 3 | 4
 */
@property (strong, nonatomic) IBOutlet UIImageView *imageView;
- (IBAction)takePhoto:(UIButton *)sender;
- (IBAction)selectPhoto:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UIImageView *imageView2;
@property (strong, nonatomic) IBOutlet UIImageView *imageView3;
@property (strong, nonatomic) IBOutlet UIImageView *imageView4;


@end
